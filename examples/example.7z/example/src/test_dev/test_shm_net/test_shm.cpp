#include <windows.h>
#include <stdio.h>
#include <conio.h>
#include <tchar.h>
#pragma comment(lib, "user32.lib")

#ifdef WIN32
    //#define SHMEM_OBJECT_NAME "Global\\ctrl_shmem_thread"
    #define SHMEM_OBJECT_NAME "Global\\22"


    #define     int8_t      __int8
    #define     int16_t     __int16
    #define     int32_t     __int32
    #define     int64_t     __int64
    #define     uint8_t     unsigned __int8
    #define     uint16_t    unsigned __int16
    #define     uint32_t    unsigned __int32
    #define     uint64_t    unsigned __int64
#else
    #define SHMEM_OBJECT_NAME "22"
#endif

#define MAX_VALUE_NN        1024    // Maximun number of values ( SH_MEM )
#define DELAY               100     // Time delay in ms of cycle

// ---------------------------------------------------------------------------
struct struct_shmem_value           // SHM value structure
// ---------------------------------------------------------------------------
{
    char        name[36];   // Name of signal/variable
    int64_t     value;      // Value
    char        access;     // Access R/W
    int64_t     dt_update;  // Last time of update
    int64_t     dt_sync;    // Last time of sync
};
static volatile struct_shmem_value *shmem_value;    // SHM value
// ---------------------------------------------------------------------------


// ---------------------------------------------------------------------------
int main()
// ---------------------------------------------------------------------------
{
    int         i, j, shmem_size, rec_size, n_rec;
    double      f;
    uint8_t     *buf;
    uint8_t     ui8;
    uint32_t	ui32;
    //uint16_t    *ui16;
    //uint64_t    ui64;
    HANDLE      hMapFile;

// ---------------------------------------------------------------------------
    rec_size = sizeof( struct_shmem_value );            // record size

    hMapFile = OpenFileMapping( FILE_MAP_ALL_ACCESS,    // read/write access
                                FALSE,                  // do not inherit the name
                                SHMEM_OBJECT_NAME );    // name of mapping object

    if( hMapFile == NULL )
    {
        printf( "Could not open file mapping object (%d).\n", GetLastError() );
        return 1;
    }

    shmem_size = rec_size * MAX_VALUE_NN;
    buf = (uint8_t*) MapViewOfFile( hMapFile,               // handle to map object
                                    FILE_MAP_ALL_ACCESS,    // read/write permission
                                    0,
                                    0,
                                    shmem_size );

    if( buf == NULL )
    {
        printf( "Could not map view of file (%d).\n", GetLastError() );
        CloseHandle( hMapFile );
        return 1;
    }

    shmem_value = ( struct_shmem_value* ) buf;
// ---------------------------------------------------------------------------

    printf( "Numbers of records: %d\n\n", shmem_value[0].value );

    printf( "Names:\n------\n" );
    for( i = 1; i < MAX_VALUE_NN; i++ )
    {
        if( shmem_value[i].name[0] != 0 )
        {
                printf( "n=%d name= \"%s\"\n", i, shmem_value[i].name );
        }
    }

    printf( "\n" );


n_rec = shmem_value[0].value;

    // ---------------------------------------------------------------------------
    for( ;; )   // main cycle
    // ---------------------------------------------------------------------------
    {

        ui8 = (uint8_t) shmem_value[1].value;
        j = (int) shmem_value[3].value;
        f = j / 100.0;
        //printf( "bin_inp = %02X  24_inp = %.2f   \r", ui8, f );

        if( j > 700 )
        {
            j -= 300;
        }
        else
        {
            j = 400;
        }

        shmem_value[2].value = shmem_value[1].value;
        shmem_value[4].value = j;


    for( i = 1; i < n_rec; i++ )
    {
ui32 = shmem_value[i].value;
		printf( "%-32s %4d %c\n", shmem_value[i].name, ui32, shmem_value[i].access );
    }
	printf( "\n" );






        Sleep( 500 );
        //Sleep( DELAY );









//        ui8 = (uint8_t) shmem_value[1].value;
//        j = (int) shmem_value[3].value;
//        f = j / 100.0;
//        printf( "bin_inp = %02X  24_inp = %.2f   \r", ui8, f );
//
//        if( j > 700 )
//        {
//            j -= 300;
//        }
//        else
//        {
//            j = 400;
//        }
//        shmem_value[2].value = shmem_value[1].value;
//        shmem_value[4].value = j;
    }   // for( ;; )    -- main cycle
    // ---------------------------------------------------------------------------

    UnmapViewOfFile( buf );
    CloseHandle( hMapFile );
    return 0;
}
