void print_err( char *str )
{
	wxMessageBox( str );
	//fprintf( stderr, "%s CTRL: %s\n",
			 //wxDateTime::Now().Format( "[%Y/%m/%d %H:%M:%S]" ).c_str(), str );
	//fflush( stderr );
}
