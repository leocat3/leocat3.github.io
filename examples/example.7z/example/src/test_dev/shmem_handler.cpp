// ===========================================================================
class SHMEM_Handler : public wxThread
// ===========================================================================
{
	private:
		//int	i;
		int			shmem_size, rec_size, shm, n_rec;
		bool		m_cancelled;
		uint8_t		*buf;
		uint16_t	*ui16;
		uint64_t	ui64;

	public:
		SHMEM_Handler()
		{
			m_cancelled	= false;

			Create();
		}

		virtual			ExitCode Entry();
		virtual void	OnExit();
};
// ===========================================================================


// ===========================================================================
wxThread::ExitCode SHMEM_Handler::Entry()
// ===========================================================================
{
	int 		i, j;
	long		l_int;
	int64_t		t1, t2, t2_t1;
	uint8_t		ui8, bin_inp, bin_out;
	float		f;
	wxDateTime	dt;
	wxString	s;

	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	rec_size	= sizeof( struct_shmem_value );				// record size
	shmem_size	= rec_size * MAX_VALUE_NN;					// Shared memory size
	hMapFile	= CreateFileMapping( INVALID_HANDLE_VALUE,	// use paging file
									 NULL,					// default security
									 PAGE_READWRITE,		// read/write access
									 0,						// maximum object size (high-order DWORD)
									 shmem_size,			// maximum object size (low-order DWORD)
									 SHMEM_OBJECT_NAME );	// name of mapping object

	if( hMapFile == NULL)
	{
		m_cancelled = true;
		g_cancelled = 1;
	}

	buf = ( uint8_t* ) MapViewOfFile( hMapFile,				// handle to map object
									  FILE_MAP_ALL_ACCESS,	// read/write permission
									  0,
									  0,
									  ( SIZE_T ) shmem_size );
	if( buf == NULL )
	{
		m_cancelled = true;
		g_cancelled = 2;
		CloseHandle( hMapFile );
	}

	shmem_value = ( struct_shmem_value* ) buf;

	// Clear SHM
	for( i = 0; i < MAX_VALUE_NN; i++ )
	{
		for( j = 0; j < ( NAME_LENGTH + 4 ); j++ )
		{
			shmem_value[i].name[j] = 0;
		}
		//shmem_value[i].instance = shmem_value_base[i].instance;
		//shmem_value[i].access = shmem_value_base[i].access;
		//strcpy( ( char* ) shmem_value[i].name, shmem_value_base[i].name );
		//shmem_value[i].value = shmem_value_base[i].value;
	}

	n_rec = sizeof( shmem_value_base ) / rec_size;	// number of records
	for( i = 0; i < n_rec; i++ )
	{
		shmem_value[i].access = shmem_value_base[i].access;
		strcpy( ( char* ) shmem_value[i].name, shmem_value_base[i].name );
		shmem_value[i].value = shmem_value_base[i].value;
	}
	shmem_value[0].value = n_rec;

	bin_out = 0;

	while( !m_cancelled )	// Основной цикл потока
	{
		dt = wxDateTime::UNow();
		t1 = dt.GetTicks() * 1000 + dt.GetMillisecond();
		// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

		if( start_frame )
		{
			s = g_24_inp->GetValue();
			s.Replace( ".", "" );
			s.ToLong( &l_int );
			shmem_value[3].value = l_int;

			f = shmem_value[4].value / 100.0;
			s.Printf( " %.2f", f );
			g_24_out->SetValue( s );
			g_24_out->Refresh();

			bin_inp = 0;

			if( g_in_0->GetValue() ) { bin_inp |= 0x01; }
			if( g_in_1->GetValue() ) { bin_inp |= 0x02; }
			if( g_in_2->GetValue() ) { bin_inp |= 0x04; }
			if( g_in_3->GetValue() ) { bin_inp |= 0x08; }
			if( g_in_4->GetValue() ) { bin_inp |= 0x10; }
			if( g_in_5->GetValue() ) { bin_inp |= 0x20; }
			if( g_in_6->GetValue() ) { bin_inp |= 0x40; }
			if( g_in_7->GetValue() ) { bin_inp |= 0x80; }
			shmem_value[1].value = bin_inp;

			ui8 = shmem_value[2].value;
			if( bin_out != ui8 )
			{
				bin_out = ui8;
				if( ui8 & 0x01 ) { g_out_0->SetBitmap( wxBitmap( wxGetBitmapFromMemory( l_green, sizeof( l_green ) ) ) ); }
				else { g_out_0->SetBitmap( wxBitmap( wxGetBitmapFromMemory( l_grey, sizeof( l_grey ) ) ) ); }
				if( ui8 & 0x02 ) { g_out_1->SetBitmap( wxBitmap( wxGetBitmapFromMemory( l_green, sizeof( l_green ) ) ) ); }
				else { g_out_1->SetBitmap( wxBitmap( wxGetBitmapFromMemory( l_grey, sizeof( l_grey ) ) ) ); }
				if( ui8 & 0x04 ) { g_out_2->SetBitmap( wxBitmap( wxGetBitmapFromMemory( l_green, sizeof( l_green ) ) ) ); }
				else { g_out_2->SetBitmap( wxBitmap( wxGetBitmapFromMemory( l_grey, sizeof( l_grey ) ) ) ); }
				if( ui8 & 0x08 ) { g_out_3->SetBitmap( wxBitmap( wxGetBitmapFromMemory( l_green, sizeof( l_green ) ) ) ); }
				else { g_out_3->SetBitmap( wxBitmap( wxGetBitmapFromMemory( l_grey, sizeof( l_grey ) ) ) ); }
				if( ui8 & 0x10 ) { g_out_4->SetBitmap( wxBitmap( wxGetBitmapFromMemory( l_green, sizeof( l_green ) ) ) ); }
				else { g_out_4->SetBitmap( wxBitmap( wxGetBitmapFromMemory( l_grey, sizeof( l_grey ) ) ) ); }
				if( ui8 & 0x20 ) { g_out_5->SetBitmap( wxBitmap( wxGetBitmapFromMemory( l_green, sizeof( l_green ) ) ) ); }
				else { g_out_5->SetBitmap( wxBitmap( wxGetBitmapFromMemory( l_grey, sizeof( l_grey ) ) ) ); }
				if( ui8 & 0x40 ) { g_out_6->SetBitmap( wxBitmap( wxGetBitmapFromMemory( l_green, sizeof( l_green ) ) ) ); }
				else { g_out_6->SetBitmap( wxBitmap( wxGetBitmapFromMemory( l_grey, sizeof( l_grey ) ) ) ); }
				if( ui8 & 0x80 ) { g_out_7->SetBitmap( wxBitmap( wxGetBitmapFromMemory( l_green, sizeof( l_green ) ) ) ); }
				else { g_out_7->SetBitmap( wxBitmap( wxGetBitmapFromMemory( l_grey, sizeof( l_grey ) ) ) ); }
			}
		}

		// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		dt = wxDateTime::UNow();
		t2 = dt.GetTicks() * 1000 + dt.GetMillisecond();
		t2_t1 = t2 - t1;	// Время выполнения
		if( t2_t1 < DELAY )	// Меньше времени задержки - посчитать остаток ожидания
		{
			t2_t1 = DELAY - t2_t1;	
		}
		else	// Больше или равно времени задержки - время ожидания = 0
		{
			t2_t1 = 0;
		}

		if( t2_t1 )	// Если нужно, то ждем остаток времени
		{
			wxThread::Sleep( t2_t1 );
			//wxMilliSleep( t2_t1 );
		}
		// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

		if( TestDestroy() )
			m_cancelled = true;
	}	// while( !m_cancelled ) - Основной цикл потока

	return 0;
}
// ===========================================================================


// ===========================================================================
void SHMEM_Handler::OnExit()
// ===========================================================================
{
	UnmapViewOfFile( buf );
	CloseHandle( hMapFile );
}
// ===========================================================================
