#ifndef	__MyFrame__
#define	__MyFrame__


/**
@file
Subclass of	MyFrameFB
*/

#include <wx/msgdlg.h>
#include "myframe_fb.h"

//// end generated include

/**	Implementing MyFrameFB */
// ///////////////////////////////////////////////////////////////////////////
class MyFrame :	public MyFrameFB
// ///////////////////////////////////////////////////////////////////////////
{
	public:
		/**	Constructor	*/
		//MyFrame( wxWindow* parent	);
		MyFrame( wxWindow* parent,
				 wxWindowID	id = wxID_ANY,
				 const wxString& title = wxEmptyString,
				 const wxPoint&	pos	= wxDefaultPosition,
				 const wxSize& size	= wxSize( 500,300 ),
				 //long	style =	wxDEFAULT_FRAME_STYLE |	wxTAB_TRAVERSAL	);
				 long style	= wxCAPTION	|
							  wxCLOSE_BOX |
							  wxICONIZE	|
							  wxMINIMIZE |
							  wxMINIMIZE_BOX |
							  wxSYSTEM_MENU	|
							  wxTAB_TRAVERSAL );
		~MyFrame();

		//wxBitmap	wxGetBitmapFromMemory( const void *data, size_t	length );

		// Event handlers, overide them	in your	derived	class
		void OnClose( wxCloseEvent&	event );
		void OnScrollChanged( wxScrollEvent& event );

	//// end generated class members
};


#endif // __MyFrame__
