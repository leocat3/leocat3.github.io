///////////////////////////////////////////////////////////////////////////
// C++ code generated with wxFormBuilder (version Sep  8 2010)
// http://www.wxformbuilder.org/
//
// PLEASE DO "NOT" EDIT THIS FILE!
///////////////////////////////////////////////////////////////////////////

#ifndef __myframe_fb__
#define __myframe_fb__

#include <wx/string.h>
#include <wx/stattext.h>
#include <wx/gdicmn.h>
#include <wx/font.h>
#include <wx/colour.h>
#include <wx/settings.h>
#include <wx/checkbox.h>
#include <wx/sizer.h>
#include <wx/panel.h>
#include <wx/bitmap.h>
#include <wx/image.h>
#include <wx/icon.h>
#include <wx/statbmp.h>
#include <wx/statline.h>
#include <wx/textctrl.h>
#include <wx/slider.h>
#include <wx/frame.h>

///////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////
/// Class MyFrameFB
///////////////////////////////////////////////////////////////////////////////
class MyFrameFB : public wxFrame 
{
	private:
	
	protected:
		wxPanel* m_panel1;
		wxPanel* m_panel2;
		wxCheckBox* m_in_7;
		wxCheckBox* m_in_6;
		wxCheckBox* m_in_5;
		wxCheckBox* m_in_4;
		wxCheckBox* m_in_3;
		wxCheckBox* m_in_2;
		wxCheckBox* m_in_1;
		wxCheckBox* m_in_0;
		wxStaticText* m_staticText1;
		wxStaticText* m_staticText2;
		wxStaticText* m_staticText3;
		wxStaticText* m_staticText4;
		wxStaticText* m_staticText5;
		wxStaticText* m_staticText6;
		wxStaticText* m_staticText7;
		wxStaticText* m_staticText8;
		wxPanel* m_panel3;
		wxStaticBitmap* m_out_7;
		wxStaticBitmap* m_out_6;
		wxStaticBitmap* m_out_5;
		wxStaticBitmap* m_out_4;
		wxStaticBitmap* m_out_3;
		wxStaticBitmap* m_out_2;
		wxStaticBitmap* m_out_1;
		wxStaticBitmap* m_out_0;
		wxStaticText* m_staticText9;
		wxStaticText* m_staticText10;
		wxStaticText* m_staticText11;
		wxStaticText* m_staticText12;
		wxStaticText* m_staticText13;
		wxStaticText* m_staticText14;
		wxStaticText* m_staticText15;
		wxStaticText* m_staticText16;
		wxStaticLine* m_staticline1;
		wxSlider* m_slider;
		wxStaticLine* m_staticline11;
		wxStaticLine* m_staticline12;
		
		// Virtual event handlers, overide them in your derived class
		virtual void OnClose( wxCloseEvent& event ) { event.Skip(); }
		virtual void OnScrollChanged( wxScrollEvent& event ) { event.Skip(); }
		
	
	public:
		wxStaticText* msg_001;
		wxStaticText* msg_002;
		wxStaticText* msg_003;
		wxTextCtrl* m_24_inp;
		wxStaticText* msg_004;
		wxTextCtrl* m_24_out;
		
		MyFrameFB( wxWindow* parent, wxWindowID id = wxID_ANY, const wxString& title = wxEmptyString, const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxSize( -1,-1 ), long style = wxCAPTION|wxCLOSE_BOX|wxICONIZE|wxMINIMIZE|wxMINIMIZE_BOX|wxSYSTEM_MENU|wxTAB_TRAVERSAL );
		~MyFrameFB();
	
};

#endif //__myframe_fb__
