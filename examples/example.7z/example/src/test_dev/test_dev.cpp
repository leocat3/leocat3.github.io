#include "wx/wxprec.h"
#include <wx/txtstrm.h>

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

#include <wx/stdpaths.h>
#include <wx/filename.h>
#include <wx/file.h>
#include <wx/xml/xml.h>
#include <wx/grid.h>
#include <wx/mstream.h>
#include <wx/config.h>
#include <wx/socket.h>
#include <wx/textfile.h>
//#include <wx/filename.h>

//#ifdef WIN32
	//#include <windows.h>
//#endif

#include "msg.h"
#include "gbl.h"
#include "l_grey.h"
#include "l_green.h"
#include "print_err.cpp"
#include "shmem_handler.cpp"
//#include "ip_thread.cpp"
#include "myframe.cpp"		// MyFrame control

#ifndef _MY_APP
#define _MY_APP


class my : public wxApp
{
	public:
		bool OnInit();
		MyFrame *frame;
};

IMPLEMENT_APP( my )

bool my::OnInit()
{
	int				x, y;
	SHMEM_Handler	*shmem_handler;
	//IP_THREAD_W		*ip_thread_w;
	//IP_THREAD_R		*ip_thread_r;

	start_frame = false;
	g_cancelled = 0;

	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// ~~~ Create SHMEM_Handler ~~~~~~~~~ ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	shmem_handler = new SHMEM_Handler();
	if( shmem_handler->Create() == wxTHREAD_NO_ERROR )
	{
		if( shmem_handler->Run() != wxTHREAD_NO_ERROR )
		{
			print_err( "Error run SHMEM_Handler." );
			return 1;
		}
	}
	else
	{
		print_err( "Error create SHMEM_Handler" );
		return 1;
	}
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


	//	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	//	// ~~~ Create IP_THREAD Handler ~~~~~~~~~ ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	//	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	//	m_socket = NULL;
	//	ip_thread_w = new IP_THREAD_W();
	//	if( ip_thread_w->Create() == wxTHREAD_NO_ERROR )
	//	{
	//		if( ip_thread_w->Run() != wxTHREAD_NO_ERROR )
	//		{
	//			print_err( "Error run SHMEM_Handler." );
	//			return 1;
	//		}
	//	}
	//	else
	//	{
	//		print_err( "Error create SHMEM_Handler" );
	//		return 1;
	//	}






	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


	wxImage::AddHandler( new wxPNGHandler );	// PNG handler
	frame = new MyFrame( ( wxFrame* ) NULL, -1, MSG_000 );
	frame->Show( TRUE );

	frame->GetSizer()->Fit( frame );
	frame->GetSize( &x, &y );
	frame->SetMinSize( wxSize( x, y ) );
	frame->SetMaxSize( wxSize( x, y ) );

	//SetTopWindow( frame );
	//frame->Maximize();

	return true;
}

#endif _MY_APP
