int OnInit()
{
	int				i, m, n;
	long			l;
	unsigned long	ul;
	wxChar			s_sep;
	wxString		s, s1, s2, s3, s_path, s_name, s_ext;
	wxArrayString	as;

    s = wxStandardPaths().GetExecutablePath();
    wxFileName::SplitPath( s, &s_path, &s_name, &s_ext );
    s_sep	= wxFileName::DirName( s ).GetPathSeparator();
    s_name	= s_path + s_sep + s_name + ".cfg";
	ip_port	= 0;
	sn		= 0;

	// Read config data
	wxTextFile inf( s_name );
	if( inf.Exists() )
	{
//printf( "File exist\n" ); fflush( stdout );

		if( inf.Open( s_name, wxConvLocal ) )
		{
			n = 0;
			for ( s = inf.GetFirstLine(); !inf.Eof(); s = inf.GetNextLine() )
			{
				n++;
				if( as.Count() < ( unsigned int ) n )
				{
					as.Add( s );
				}
				else
				{
					as[n-1] = s;
				}				
			}
			inf.Close();

			n = as.Count();
			for( i = 0; i < n; i++ )
			{
				s = as[i];
				s = s.Trim( false );
				s = s.Trim( true );
				s = s.Upper();
				s.Replace( "\t", " " );
				s.Replace( "  ", " " );
				if( s != wxEmptyString )
				{
//printf( "s=%s\n", s.c_str() ); fflush( stdout );
					// Parse parameter string
					s1 = s2 = s3 = wxEmptyString;
					m = s.Find( ' ', true );
					if( m != wxNOT_FOUND )
					{
						s3 = s.Mid( m + 1 );
						s.Truncate( m );
						m = s.Find( ' ', true );
						if( m != wxNOT_FOUND )
						{
							s2 = s.Mid( m + 1 );
							s.Truncate( m );
							s1 = s;
						}
					}

					if( s1 == wxT( "NET" ) )		// Net config
					{
						if( s2 == wxT( "IP" ) )		// IP address
						{
							ip_addr = s3;
						}
						else
						if( s2 == wxT( "PORT" ) )	// IP port
						{
							if( s3.ToLong( &l ) )
							{
								if( ( l > 0 ) && ( l < 0xFFFF ) )
								{
									ip_port = l;
								}
								else
								{
									print_err( "Bad IP port." );
									return 3;
								}
							}
							else
							{
								print_err( "Bad IP port." );
								return 2;
							}
						}
					}	// if( s1 == wxT( "NET" ) )

					else
					if( s1 == wxT( "CFG" ) )		// System config
					{
						if( s2 == wxT( "SN" ) )		// S/N
						{
							if( s3.ToULong( &ul ) )
							{
								sn = ul;
							}
							else
							{
								print_err( "Bad S/N." );
								return 2;
							}
						}
					}	// if( s1 == wxT( "NET" ) )
				}	// if( s != wxEmptyString )
			}	// for( i = 0; i < n; i++ )

			if( ( ip_port <= 0 ) || ( ip_port > 0xFFFF ) )
			{
				ip_port = IP_PORT;
			}

//printf( "=======================================\n", ip_port );
//printf( "SN   =%d\n", sn ); fflush( stdout );
//printf( "PORT =%d\n", ip_port ); fflush( stdout );

			return 0;
		}	// if( inf.Open( file_name, wxConvLocal ) )
	}	// if( inf.Exists() )

	print_err( "Config file not exist." );
    return 1;
}
