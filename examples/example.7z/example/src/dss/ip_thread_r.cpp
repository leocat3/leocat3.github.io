// ===========================================================================
// Service of ETH support
// Communicate between systems
// Read from socket
// ===========================================================================


// ===========================================================================
class IP_THREAD_R : public wxThread
// ===========================================================================
{
	private:
		int				mon_index;
		int				shmem_size, rec_size;
		int				len_rec, len_name;
		bool			m_cancelled, shmem_create;
		uint8_t			*buf, read_buffer[IP_SIZE], name[132], access;
		uint64_t		value;

		wxSocketBase	*m_socket;
		wxIPV4address	addr_info;
		wxString		shmem_object_name;

		HANDLE			hMapFile;
		volatile struct_shmem_value	*shmem_value;

	public:
		IP_THREAD_R( wxSocketBase *p_socket )
		{
			m_cancelled		= false;
			shmem_create	= false;
			m_socket		= p_socket;

			Create();
		}

		virtual			ExitCode Entry();
		virtual void	OnExit();
};
// ===========================================================================


// ===========================================================================
wxThread::ExitCode IP_THREAD_R::Entry()
// ===========================================================================
{
	int		i, j, l, n, len;

	//int		len_rec, len_name;
	char	cs[256];
//wxString	s;

	wxDateTime	dt;

	uint8_t		*ui8, ui8a[40];
	uint32_t	*ui32, record_index;
	uint64_t	time_in_ticks;

	mon_index	= 0;
	len_rec		= 0;
	len_name	= sizeof( shmem_value[0].name );

printf( "R thread: len_name = %d\n", len_name ); fflush( stdout );

	for( i = 1; i < MAX_CONNECT_NN; i++ )
	{
		if( shmem_mon[i].socket == ( int ) m_socket )	// search sock
		{
			mon_index = i;
			break;
		}
	}

	if( mon_index > 0 )
	{
		if( m_socket )
		{
			if( m_socket->WaitForRead( -1 ) )
			{
				//m_socket->Read( (uint8_t*) read_buffer, IP_SIZE );	// read buffer from admin
				m_socket->Read( (uint8_t*) read_buffer, 6 );	// read buffer from admin
				len = m_socket->LastCount();

				// First packet ( SN )
				if( len < 6 )	// 2 bytes function ID; 4 bytes SN ( uint32_t )
				{
					m_cancelled = true;
				}
				else
				{
					if( ( read_buffer[0] == 1 ) && ( read_buffer[1] == 1 ) )	// label for start connect
					{
						ui32	= ( uint32_t* ) &ui8a;	// get SN
						ui8a[0] = read_buffer[2];
						ui8a[1] = read_buffer[3];
						ui8a[2] = read_buffer[4];
						ui8a[3] = read_buffer[5];

printf( "R thread: b1=%d b2=%d %d %8X\n", read_buffer[0], read_buffer[1], *ui32, *ui32 ); fflush( stdout );

						// ---------------------------------------------------------------------------
						// Create shared memory for instance
						// ---------------------------------------------------------------------------
						shmem_object_name.Printf( "Global\\%d", *ui32 );

printf( "R thread: SHM Name: >%s<\n", shmem_object_name.c_str() ); fflush( stdout );
					
						rec_size = sizeof( struct_shmem_value );
						shmem_size = rec_size * MAX_VALUE_NN;

printf( "R thread: rec_size = %d   shmem_size = %d\n", rec_size, shmem_size ); fflush( stdout );
	
						hMapFile = CreateFileMapping( INVALID_HANDLE_VALUE,			// use paging file
													  NULL,							// default security
													  PAGE_READWRITE,				// read/write access
													  0,							// maximum object size (high-order DWORD)
													  shmem_size,					// maximum object size (low-order DWORD)
													  shmem_object_name.c_str() );	// name of mapping object
		
						if( hMapFile == NULL )
						{
							print_err( "Failed to create read SHM." );
							m_cancelled = true;
						}

printf( "R thread: Map SHM buffer to array\n" ); fflush( stdout );
	
						// Map SHM buffer to array
						if( !m_cancelled )
						{
							buf = ( uint8_t* ) MapViewOfFile( hMapFile,				// handle to map object
															FILE_MAP_ALL_ACCESS,	// read/write permission
															0,
															0,
															( SIZE_T ) shmem_size );
							if( buf == NULL )
							{
								print_err( "Failed to create buffer read SHM." );
								m_cancelled = true;
								CloseHandle( hMapFile );
							}
						}
	
//printf( "R thread: buf1 = %d\n", buf ); fflush( stdout );
	
						// Clear SHM records
						if( !m_cancelled )
						{
							shmem_create	= true;
							shmem_value		= ( struct_shmem_value* ) buf;
							//len = sizeof( shmem_value[0].name );
							len_rec	= 4 + len + 2 + 8;	// Lenth name + header + length access + length value
printf( "R thread: len_rec = %d\n", len_rec );
	
							// Clear chared memory
							for( i = 0; i < MAX_VALUE_NN; i++ )
							{
								for( j = 0; j < len_name; j++ )
								{
									shmem_value[i].name[j] = 0;
								}
								shmem_value[i].value		= 0;
								shmem_value[i].access		= 0;
								shmem_value[i].dt_update	= 0;
								shmem_value[i].dt_sync		= 0;
							}
							shmem_value[0].access = '*';
						}	// if( !m_cancelled )
						// ---------------------------------------------------------------------------

						shmem_mon[mon_index].instance = *ui32;

					}	// if( ( read_buffer[0] == 1 ) && ( read_buffer[1] == 1 ) )
					else
					{
						m_cancelled = true;
						m_socket->GetPeer( addr_info );
						sprintf( cs, "Wrong header of S/N packet; IP=%s", addr_info.IPAddress().c_str() );
						print_err( cs );
					}
				}
			}	// if( socket->WaitForRead( -1 ) )
		}	// if( socket )

//printf( "001\n" ); fflush( stdout );
	}	// if( mon_index > 0 )
	else
	{
		m_cancelled = true;
		print_err( "IP_Read - Exceeding of MAX_CONNECT_NN." );
	}


	// ---------------------------------------------------------------------------
	while( !m_cancelled )	// Main cycle
	// ---------------------------------------------------------------------------
	{
		if( m_socket )
		{
			if( m_socket->WaitForRead( -1 ) )
			{
				m_socket->Read( (uint8_t*) read_buffer, 2 );	// read len and count of packets
//printf( "R thread: read len=%d n_pkt=%d\n", read_buffer[0], read_buffer[1] ); fflush( stdout );
				l = read_buffer[0];	// length of block
				n = read_buffer[1];	// count of blocks
				for( i = 0; i < n; i++ )
				{
					m_socket->Read( (uint8_t*) read_buffer, l );	// read packet to buffer
					len = m_socket->LastCount();

					if( len == l )	// If len equal l
					{
						/* -----------------------------------------------------------------------
						Packet description

						record_index	4 bytes		index in SHM
						name			36 bytes	name
						p_sn			1 byte		cyclic sequental number of packet
						access			1 byte		Access
						value			8 bytes		Value
						----------------------------------------------------------------------- */

						// Get index in SHM
						ui8 = ( uint8_t* ) &record_index;
						for( j = 0; j < 4; j++ )
						{
							ui8[j] = read_buffer[j];
						}

						// Get name
						for( j = 0; j < len_name; j++ )
						{
							name[j] = read_buffer[j+4];
						}

						access = read_buffer[len_name+4];

						ui8 = ( uint8_t* ) &value;
						for( j = 0; j < 8; j++ )
						{
							ui8[j] = read_buffer[len_name+j+6];
						}

//printf( "R thread: sock=%d index=%d n=%3d p_sn=%3d access=%c name=%s value=%d\n",
//m_socket,
//record_index,
//i,
//read_buffer[41],
//access,
//name,
//value ); fflush( stdout );

						if( record_index < MAX_VALUE_NN )
						{
							// Set variable name
							//k = sizeof( shmem_value[0].name );
							for( j = 0; j < len_name; j++ )
							{
								shmem_value[record_index].name[j] = name[j];
							}

							if( ( access == 'w' ) || ( access == 'W' ) )
							{
								access = 'R';
							}
							else
							if( ( access == 'r' ) || ( access == 'R' ) )
							{
								access = 'W';
							}

							if( record_index != 0 )	// In record 0 access is control flag
							{
								shmem_value[record_index].access = access;	// Access
							}

							if( ( access == 'R' ) || ( access == '*' ) || ( record_index == 0 ) )
							{
								dt = wxDateTime::UNow();
								//time_in_ticks = dt.GetTicks() * 1000 + dt.GetMillisecond();
//								time_in_ticks = dt.GetTicks();
//								time_in_ticks = time_in_ticks << 10;
//								time_in_ticks = time_in_ticks | dt.GetMillisecond();
//								time_in_ticks = time_in_ticks & 0xFFFFFFFF;
								time_in_ticks = dt.GetTicks();
								time_in_ticks *= 1000;
								time_in_ticks += dt.GetMillisecond();



if( shmem_value[record_index].dt_sync != 0 )
{


}



//shmem_value[record_index].dt_update = time_in_ticks;	// Last time of update

								shmem_value[record_index].dt_sync = time_in_ticks;	// Last time of sync
								shmem_value[record_index].value = value;			// Set Value
							}
						}	// if( record_index < MAX_VALUE_NN )
					}	// if( len == l )
				}	// for( i = 0; i < n; i++ )
//printf( "---------------\n\n" );
//printf( "R thread: sock=%d len=%d\n", m_socket, len ); fflush( stdout );

				if( !m_socket->IsOk() )
				{
					m_cancelled = TRUE;
//printf( "R thread: 002\n" ); fflush( stdout );
				}

				if( m_socket->IsDisconnected()  )
				{
					m_cancelled = TRUE;
//printf( "R thread: 003\n" ); fflush( stdout );
				}

				if( m_socket->Error()  )
				{
					m_cancelled = TRUE;
//printf( "R thread: 004\n" ); fflush( stdout );
				}
			}	// if( m_socket->WaitForRead( -1 ) )
		}	// if( m_socket )

		if( shmem_value[0].access == 'C' )	// Close socke command
		{
			m_cancelled = true;
		}

	}	// while( !m_cancelled )	-- Основной цикл

	return 0;
}
// ===========================================================================


// ===========================================================================
void IP_THREAD_R::OnExit()
// ===========================================================================
{
	int	i, j;
	//uint32_t	*ui32;

	// ??? Clear record in MON table ( SHM )
	mon_index = 0;
	for( i = 1; i < MAX_CONNECT_NN; i++ )
	{
		if( shmem_mon[i].socket == ( int ) m_socket )	// search sock
		{
			mon_index = i;
printf( "R thread: close index=%d\n", i); fflush( stdout );
			break;
		}
	}

	// Clear record
	if( mon_index > 0 )
	{
		shmem_mon[mon_index].socket = 0;
		shmem_mon[mon_index].instance = 0;
		for( i = 0; i < 44; i++ )
		{
			shmem_mon[mon_index].ip[i] = 0;
		}
		//shmem_mon[mon_index].status = 0;
	}

	if( m_socket )
	{
		m_socket->Close();
		delete m_socket;
		m_socket = NULL;
	}

	if( shmem_create )
	{
		// Clear chared memory
		for( i = 0; i < MAX_VALUE_NN; i++ )
		{
			for( j = 0; j < len_name; j++ )
			{
				shmem_value[i].name[j] = 0;
			}
			shmem_value[i].value		= 0;
			shmem_value[i].access		= 0;
			shmem_value[i].dt_update	= 0;
			shmem_value[i].dt_sync		= 0;
		}

		UnmapViewOfFile( buf );
		CloseHandle( hMapFile );
	}
//printf( "R thread: Close IP_THREAD_R::Entry()\n"); fflush( stdout );
}
// ===========================================================================
