void print_err( char *str )
{
	fprintf( stderr, "%s DSS: %s\n",
			 wxDateTime::Now().Format( "[%Y/%m/%d %H:%M:%S]" ).c_str(), str );
	fflush( stderr );
}
