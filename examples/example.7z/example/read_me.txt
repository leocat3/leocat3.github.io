The compiled tasks are located in the folder ./exe

test_dev.exe - Test_dev.exe - controller simulator. Creates a shared memory of
controller.

Test_shm.exe is the local agent for working with signals on the controller
side, is connected to named shared memory.

Option for testing agents through the IP network:
- Run simulator test_dev.exe, it will create a Named Shared Memory.
- Run command s1.cmd, this command will raise two console tasks: the control
  agent and the server agent.
  Automatically creates a connection. Port of 31001 on IP 127.0.0.1
  The task test_shm_net.exe is working with signals on the server side.

In the source, you can see an example of working with Named Shared Memory on
the server side.

Test_shm_net.exe and test_shm.exe together it is desirable not to run, each of
them will control the signals. As a result - a mess.

Pict.pdf - a picture demonstrating the concept of architecture.

WxWidgets v2.8 package was used.

Running applications must be performed with administrator rights.
