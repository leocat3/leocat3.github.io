#ifndef WX_PRECOMP
	#include "wx/wx.h"
#endif

#include "wx/string.h"
#include "wx/app.h"
#include "wx/snglinst.h"
#include "wx/socket.h"
#include <wx/dynarray.h>
#include <wx/thread.h>
#include <wx/datetime.h>
#include <wx/textfile.h>
#include <wx/filename.h>

#include <stdio.h>

#ifdef WIN32
	#include <windows.h>
	#include <conio.h>
	#pragma comment(lib, "user32.lib")
//#else
#endif

#include "gbl.h"
#include "print_err.cpp"
#include "ip_thread_r.cpp"
#include "ip_thread_w.cpp"
#include "ip_thread.cpp"


int main()
{
	wxString		s;
	wxInitializer	initializer;
	IP_THREAD_MON	*ip_mon;

	EXIT_STATUS = FALSE;

// ---------------------------------------------------------------------------
// wxWindows checkers
// ---------------------------------------------------------------------------
	if ( !initializer )
	{
		print_err( "Failed to initialize the wxWidgets library.");
		return 1;
	}
// ---------------------------------------------------------------------------


// ---------------------------------------------------------------------------
// Start sockets monitor
// ---------------------------------------------------------------------------
	ip_mon = new IP_THREAD_MON();
	if( ip_mon->Create() == wxTHREAD_NO_ERROR )
	{
		if( ip_mon->Run() != wxTHREAD_NO_ERROR )
		{
			print_err( "IP_THREAD_MON Error run." );
			return 1;
		}
	}
	else
	{
		print_err( "IP_THREAD_MON Error create." );
		return 1;
	}
// ---------------------------------------------------------------------------

    printf( "Start DSS; IP port=%d\n", PORT_SRV );

// ---------------------------------------------------------------------------
// main cycle
// ---------------------------------------------------------------------------
    for( ;; )
    {
		if( EXIT_STATUS )
		{
			return 1;
		}
        Sleep( 1000 );
    }

    return 0;
}
