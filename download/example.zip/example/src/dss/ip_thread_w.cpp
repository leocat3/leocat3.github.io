// ===========================================================================
// Service of ETH support
// Communicate between systems
// Write to socket
// ===========================================================================


// ===========================================================================
class IP_THREAD_W : public wxThread
// ===========================================================================
{
	private:
		int				mon_index, time_index;
		bool			m_cancelled;
		uint8_t			*buf, write_buffer[IP_SIZE];
		wxSocketBase	*m_socket;
		int				shmem_size, rec_size;
		wxString		shmem_object_name;

		HANDLE			hMapFile;
		volatile struct_shmem_value	*shmem_value;

	public:
		IP_THREAD_W( wxSocketBase *p_socket )
		{
			m_cancelled	= true;
			m_socket	= p_socket;

			Create();
		}
//
		virtual			ExitCode Entry();
		virtual void	OnExit();
};
// ===========================================================================


// ===========================================================================
wxThread::ExitCode IP_THREAD_W::Entry()
// ===========================================================================
{
	int			i, j, k, n, len, nn_blk, count_rec, max_nn_rec, len_name;
	uint8_t		*ui8, ui8a[4], p_sn, len_rec;
	uint32_t	*ui32, record_index;
	uint64_t	*ui64, value, tim1;

//int			i, j, k, l, m, n, len;
	//int	i, len;
	//uint32_t	*ui32;
	//uint64_t	tim1, tim2;

wxDateTime	dt;

//printf( "W thread: Start IP_W\n" ); fflush( stdout );

	// Search index of socket in MON SHM
	mon_index = 0;
	for( i = 1; i < MAX_CONNECT_NN; i++ )
	{
		if( shmem_mon[i].socket == ( int ) m_socket )	// search sock
		{
			mon_index = i;
			//m_cancelled = false;
//printf( "W thread: index (w) = %d\n", i); fflush( stdout );
			break;
		}
	}

	if( mon_index > 0 )
	{
		//m_cancelled = false;

		// Wait for socket value in SHM; open SHM of socket
		n = 0;
		while( ( shmem_mon[mon_index].socket == ( int ) m_socket ) && ( shmem_mon[mon_index].instance == 0 ) )
		{
			wxThread::Sleep( DELAY );
			n++;
			if( n > 100 )
			{
				break;
			}
		}

		if( ( shmem_mon[mon_index].socket == ( int ) m_socket ) && ( shmem_mon[mon_index].instance != 0 ) )
		{
			shmem_object_name.Printf( "Global\\%d", shmem_mon[i].instance );

printf( "W thread: instance (w) = %s\n", shmem_object_name.c_str() ); fflush( stdout);
//m_cancelled = false;



//hMapFile = NULL;

//			hMapFile = CreateFileMapping( INVALID_HANDLE_VALUE,			// use paging file
//										NULL,							// default security
//										PAGE_READWRITE,				// read/write access
//										0,							// maximum object size (high-order DWORD)
//										shmem_size,					// maximum object size (low-order DWORD)
//										shmem_object_name.c_str() );	// name of mapping object


			rec_size = sizeof( struct_shmem_value );
			shmem_size = rec_size * MAX_VALUE_NN;

printf( "W thread: rec_size = %d   shmem_size = %d\n", rec_size, shmem_size ); fflush( stdout );

			n			= 0;
			hMapFile	= NULL;
			while( hMapFile == NULL )
			{
printf( "W thread: OpenFileMapping; n = %d\n", n ); fflush( stdout );
				hMapFile = OpenFileMapping( FILE_MAP_ALL_ACCESS,    // read/write access
											FALSE,                  // do not inherit the name
											shmem_object_name );    // name of mapping object
				wxThread::Sleep( DELAY );
				n++;
				if( n > 100 )
				{
					break;
				}
			}

			if( hMapFile == NULL )
			{
				print_err( "Failed to create write SHM." );
				//m_cancelled = true;
			}	// if( hMapFile == NULL )
			else
			{
				buf = (uint8_t*) MapViewOfFile( hMapFile,               // handle to map object
												FILE_MAP_ALL_ACCESS,    // read/write permission
												0,
												0,
												shmem_size );
				if( buf == NULL )
				{
					print_err( "Failed to create buffer write SHM." );
					//m_cancelled = true;
					CloseHandle( hMapFile );
				}	// if( buf == NULL )
				else
				{
					m_cancelled = false;
				}
			}	// else - if( hMapFile == NULL )
		}	// if( ( shmem_mon[mon_index].socket == ( int ) m_socket ) && ( shmem_mon[mon_index].instance != 0 ) )
	}	// if( mon_index > 0 )

	shmem_value	= ( struct_shmem_value* ) buf;
	len_name	= sizeof( shmem_value[0].name );
	len_rec		= 4 + len_name + 2 + 8;	// Index of record + Lenth name + p_sn + length access + length value
	max_nn_rec	= IP_MAX_BLOCK_LEN / len_rec;
	p_sn		= 0;

n = 0;
time_index = 0;
for( i = 1; i < MAX_VALUE_NN; i++ )
{
if( !strcmp( ( char* ) shmem_value[i].name, "SRV_TIMER" ) )
{
time_index = i;
break;
}
}
printf( "W thread: time_index = %d\n", time_index ); fflush( stdout );











printf( "W thread: len_rec = %d max_nn_rec = %d\n", len_rec, max_nn_rec ); fflush( stdout );

	// ---------------------------------------------------------------------------
	while( !m_cancelled )	// Основной цикл
	// ---------------------------------------------------------------------------
	{
		if( m_socket )	// sock is OK
		{
			/* -----------------------------------------------------------------------
			Packet description

			record_index	4 bytes		index in SHM
			name			36 bytes	name
			p_sn			1 byte		cyclic sequental number of packet
			access			1 byte		Access
			value			8 bytes		Value
			----------------------------------------------------------------------- */

	//	//len = 10;

			if( m_socket->IsConnected() )
			{

//printf( "W thread: w" ); fflush( stdout);


//dt = wxDateTime::UNow();
////time_in_ticks = dt.GetTicks() * 1000 + dt.GetMillisecond();
//time_in_ticks = dt.GetTicks();
//time_in_ticks = time_in_ticks << 10;
//time_in_ticks = time_in_ticks | dt.GetMillisecond();
//time_in_ticks = time_in_ticks & 0xFFFFFFFF;

//i = 0;
//printf( "W thread: name=%s access=%c\n", shmem_value[0].name, shmem_value[0].access ); fflush( stdout );
//n = shmem_value[0].value;
//printf( "W thread: n=%d\n", n ); fflush( stdout );

				k = 2;	// 0 byte is length of record; 1 byte is count of record in block
				nn_blk	= 0;
				n = shmem_value[0].value;
//printf( "W thread: n = %d\n", n ); fflush( stdout );
				for( i = 0; i < n; i++ )
				{
//printf( "W thread: access=%c\n", shmem_value[i].access ); fflush( stdout );



if( time_index )
{
dt = wxDateTime::UNow();
//time_in_ticks = dt.GetTicks() * 1000 + dt.GetMillisecond();
tim1 = dt.GetTicks();
//tim1 = tim1 << 10;
//tim1 = tim1 | dt.GetMillisecond();
//tim1 = tim1 & 0xFFFFFFFF;

tim1 *= 1000;
tim1 += dt.GetMillisecond();
//tim1 = tim1 & 0xFFFFFFFF;

shmem_value[time_index].value = tim1;


}


					if( ( shmem_value[i].access == 'W' ) || ( shmem_value[i].access == 'w' ) )
					{
printf( "W thread: name=%s\n", shmem_value[i].name ); fflush( stdout );

						record_index = i;
						ui8 = ( uint8_t* ) &record_index;
						for( j = 0; j < 4; j++ )					// record index
						{
							write_buffer[k] = ui8[j];
							k++;
						}

						for( j = 0; j < len_name; j++ )				// name
						{
							write_buffer[k] = shmem_value[i].name[j];
							k++;
						}

						write_buffer[k++] = shmem_value[i].access;	// access
						write_buffer[k++] = p_sn;					// cyclic nn of packet
						p_sn++;
						ui8 = ( uint8_t* ) &shmem_value[i].value;	// value to buffer

//ui8 = ( uint8_t* ) &value;	// value to buffer
//printf( "W thread: value = %lld\n", value ); fflush( stdout );
	
						for( j = 0; j < 8; j++ )
						{
							write_buffer[k++] = ui8[j];
						}
						nn_blk++;
						if( ( nn_blk == max_nn_rec ) || ( ( i == n - 1 ) ) )
						{
printf( "W thread: nn_blk = %d k = %d\n", nn_blk, k ); fflush( stdout );
							write_buffer[0] = len_rec;
							write_buffer[1] = nn_blk;
							nn_blk = 0;

							// write block
							m_socket->WaitForWrite( -1 );
							m_socket->Write( write_buffer, k );
							k = 2;	// reset bytes count
						}
					}	// if( shmem_value[i].access == 'W' )
				}	// for( i = 0; i < n; i++ )
			}	// if( m_socket->IsConnected() )
		}	// if( m_socket ) --  sock is OK

		wxThread::Sleep( DELAY );
		if( shmem_mon[mon_index].socket != ( int ) m_socket )
		{
			m_cancelled = true;
		}
	}
	return 0;
}
// ===========================================================================


// ===========================================================================
void IP_THREAD_W::OnExit()
// ===========================================================================
{

printf( "W thread: Close IP_THREAD_W::Entry()\n"); fflush( stdout );

}
// ===========================================================================
