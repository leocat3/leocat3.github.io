#ifndef __GBL__
#define __GBL__

#ifdef WIN32	// if Win then declare nix-like types
    #define     int8_t      __int8
    #define     int16_t     __int16
    #define     int32_t     __int32
    #define     int64_t     __int64
    #define     uint8_t     unsigned __int8
    #define     uint16_t    unsigned __int16
    #define     uint32_t    unsigned __int32
    #define     uint64_t    unsigned __int64
#endif			// WIN32

// Declare name of shared memory
#ifdef WIN32
	#define SHMEM_OBJECT_NAME "Global\\shmem_mon"
	HANDLE	hMapFile_MON;
	//HANDLE	hMapFile;
#else
	#define SHMEM_OBJECT_NAME "shmem_mon"
#endif

#define PORT_SRV			31001	// IP port for SHM service
#define IP_SIZE				2048	// Buffers size
#define IP_MAX_BLOCK_LEN	700		// Maximum lenght of IP block for write
#define CONNECT_TIMEOUT		3		// Connect timeout in sec.
#define TIMEOUT				5		// Socket timeout in sec
#define MAX_CONNECT_NN		1024	// Maximun number of connects
#define MAX_VALUE_NN		1024	// Maximun number of values ( SH_MEM )
#define DELAY				1000	// Time delay in ms of read/write cycles


// ***************************************************************************
// Shared memory support
// ***************************************************************************
struct  struct_shmem_mon
{
	int			socket;				// socket ptr
	uint32_t	instance;			// instance number ( S/N )
	char		ip[44];				// ip
};
static volatile struct_shmem_mon *shmem_mon;

struct struct_shmem_value			// SHM value structure
{
    char        name[36];			// Name of signal/variable
    int64_t     value;				// Value
    char        access;				// Access R/W
    int64_t     dt_update;			// Last time of update
    int64_t     dt_sync;			// Last time of sync
};
//static volatile struct_shmem_value *shmem_value;	// SHM value
// ***************************************************************************

static volatile bool	EXIT_STATUS;






#endif //__GBL__
