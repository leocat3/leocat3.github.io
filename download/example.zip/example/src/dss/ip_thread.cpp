// ===========================================================================
// Service of ETH support
// Communicate between systems
// Monitor
// ===========================================================================


// ===========================================================================
class IP_THREAD_MON : public wxThread
// ===========================================================================
{
	private:
		bool			m_cancelled, max_socket_count;
		int				shmem_size, rec_size, shm, n_rec;
		//int				m_shmem_size, m_rec_size, m_shm, m_n_rec;
	    uint8_t			*buf;

        //bool	close;

		//uint8_t	read_buffer[IP_SIZE];
		//uint8_t	write_buffer[IP_SIZE];

		wxIPV4address	addr, addr_info;
		wxSocketServer	*server;
		wxSocketBase	*socket;

		IP_THREAD_R		*ip_read;
		IP_THREAD_W		*ip_write;

		//wxSocketClient	*m_socket;					// Адрес соккета клиента

	public:
		IP_THREAD_MON()
		{
			m_cancelled			= false;
			max_socket_count	= false;
			socket				= NULL;
			rec_size			= sizeof( struct_shmem_mon );	// record size
			shmem_size			= rec_size * MAX_CONNECT_NN;	// shared memory size

			//addr.Hostname( "127.0.0.1" );

			Create();
		}

		virtual			ExitCode Entry();
		virtual void	OnExit();

};
// ===========================================================================


// ===========================================================================
wxThread::ExitCode IP_THREAD_MON::Entry()
// ===========================================================================
{
	int	i, j, len;

wxString s;

	addr.Service( PORT_SRV );	// Set port for listen
	//addr.Hostname( IP_ADDR );

//s.Printf( "% 14u", 0xffffffff );
//printf( "% 20u\n", 0xffffffff );


// ---------------------------------------------------------------------------
// Create mon shared memory
// ---------------------------------------------------------------------------
	hMapFile_MON = CreateFileMapping( INVALID_HANDLE_VALUE,	// use paging file
									  NULL,					// default security
									  PAGE_READWRITE,		// read/write access
									  0,					// maximum object size (high-order DWORD)
									  shmem_size,			// maximum object size (low-order DWORD)
									  SHMEM_OBJECT_NAME );	// name of mapping object

	if( hMapFile_MON == NULL )
	{
		print_err( "Failed to create MON SHM." );
		m_cancelled = true;
	}

	// отобразить буфер на массив записей
	if( !m_cancelled )
	{
		buf = ( uint8_t* ) MapViewOfFile( hMapFile_MON,			// handle to map object
										  FILE_MAP_ALL_ACCESS,	// read/write permission
										  0,
										  0,
										  ( SIZE_T ) shmem_size );
		if( buf == NULL )
		{
			print_err( "Failed to create buffer MON SHM." );
			m_cancelled = true;
			CloseHandle( hMapFile_MON );
		}
	}

	// очистить записи
	if( !m_cancelled )
	{
		shmem_mon = ( struct_shmem_mon* ) buf;
		len = sizeof( shmem_mon[0].ip );

		// Clear chared memory
		for( i = 0; i < MAX_CONNECT_NN; i++ )
		{
			shmem_mon[i].socket = 0;
			shmem_mon[i].instance = 0;
			//shmem_mon[i].status = ' ';
			for( j = 0; j < len; j++ )
			{
				shmem_mon[i].ip[j] = 0;
			}
			//shmem_mon[i].status = '-';
		}
		shmem_mon[0].socket = MAX_CONNECT_NN;
// ---------------------------------------------------------------------------


		// Create socket server
		if( !addr_info.Service( PORT_SRV ) )	// Fort already in use; error
		{
			s.Printf( "Fort %d already in use.", PORT_SRV );
			print_err( ( char* ) s.c_str() );
			m_cancelled = true;
		}
		else
		{
			server = new wxSocketServer( addr );
			if ( !server->Ok() )
			{
				if( server )
					server->Destroy();
				print_err( "Failed to start socket server." );
				m_cancelled = true;
			}
		}
	}	// if( !m_cancelled )


	// ---------------------------------------------------------------------------
	while( !m_cancelled )	// Основной цикл
	// ---------------------------------------------------------------------------
	{
		if( server && server->WaitForAccept( -1, 1000 ) )	// wait for accept of connection
		{
printf("WaitForAccept\n"); fflush( stdout );
			socket = NULL;
			// В случае нового соединения создаем сокет для клиента
			// Создаем потоки для обслуживания запросов ( R/W )
			// Сохраняем адрес соккета в массиве shmem_mon
			// Сохраняем IP в массиве shmem_mon
			// SN ( ID ) будет получен в потоке чтеиия первой операцией
			socket = server->Accept();

			if( socket )
			{
printf("Accept connection\n"); fflush( stdout );
				j = 0;
				for( i = 1; i < MAX_CONNECT_NN; i++ )	// seach empty socket
				{
					if( shmem_mon[i].socket == 0 )
					{
						j = i;
						break;
					}
					//shmem_mon[i].status = '-';
				}

				if( j > 0 )
				{
					socket->GetPeer( addr_info );
					shmem_mon[j].socket = ( int ) socket;
					strcpy( ( char* ) shmem_mon[j].ip, addr_info.IPAddress().c_str() );
printf( "IP=%s\n", shmem_mon[j].ip ); fflush( stdout );
//printf( "%s %s : %d\n", addr_info.IPAddress().c_str(), addr_info.Hostname().c_str(), addr_info.Service() ); fflush( stdout );

					// Start read thread
					ip_read = new IP_THREAD_R( socket );
					if( ip_read->Create() == wxTHREAD_NO_ERROR )
					{
						if( ip_read->Run() != wxTHREAD_NO_ERROR )
						{
							print_err( "IP_THREAD_R error run." );
							m_cancelled = true;
							//return 0;
						}
					}
					else
					{
						print_err( "IP_THREAD_R error create." );
						m_cancelled = true;
						//return 0;
					}

					// Start write thread
					if( !m_cancelled )
					{
						ip_write = new IP_THREAD_W( socket );
						if( ip_write->Create() == wxTHREAD_NO_ERROR )
						{
							if( ip_write->Run() != wxTHREAD_NO_ERROR )
							{
								print_err( "IP_THREAD_W error run." );
								m_cancelled = true;
								//return 0;
							}
						}
						else
						{
							print_err( "IP_THREAD_W error create." );
							m_cancelled = true;
							//return 0;
						}
					}
				}
				else
				{
					print_err( "Exceed MAX_CONNECT_NN limit." );
				}
			}	// if( socket )
		}	// if( server && server->WaitForAccept( -1, 1000 ) )

print_err( "Wait..." );

		if( TestDestroy() )
			m_cancelled = true;

	}	// while( !m_cancelled )
	// ---------------------------------------------------------------------------

	print_err( "Close MON thread." );
	EXIT_STATUS = TRUE;
	return 0;
}
// ===========================================================================


// ===========================================================================
void IP_THREAD_MON::OnExit()
// ===========================================================================
{
	UnmapViewOfFile( buf );
	CloseHandle( hMapFile_MON );
}
// ===========================================================================
