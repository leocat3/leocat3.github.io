#ifndef __GBL__
#define __GBL__

//#define WIN32
#ifdef WIN32	// if Win then declare nix-like types
    #define     int8_t      __int8
    #define     int16_t     __int16
    #define     int32_t     __int32
    #define     int64_t     __int64
    #define     uint8_t     unsigned __int8
    #define     uint16_t    unsigned __int16
    #define     uint32_t    unsigned __int32
    #define     uint64_t    unsigned __int64
#endif			// WIN32

// Declare name of shared memory
#ifdef WIN32
	#define SHMEM_OBJECT_NAME "Global\\test_dev"
	HANDLE	hMapFile;
#else
	#define SHMEM_OBJECT_NAME "test_dev"
#endif

#define IP_PORT				31001	// IP port for SHM service
#define IP_SIZE				2048	// Buffers size
#define CONNECT_TIMEOUT		3		// Connect timeout in sec.
#define TIMEOUT				5		// Socket timeout in sec
#define MAX_VALUE_NN		1024	// Maximun number of values ( SH_MEM )
//#define DELAY				100		// Time delay in ms of write cycle ( sync ) 
#define DELAY				1000	// Time delay in ms of write cycle ( sync )

static uint32_t				sn;
static wxString				ip_addr;
static unsigned short 		ip_port;
static wxIPV4address		addr;
static wxSocketClient		*sock_client;


// ===========================================================================
struct struct_shmem_value			// SHM value structure
// ===========================================================================
{
    char        name[36];	// Name of signal/variable
    int64_t     value;		// Value
    char        access;		// Access R/W
    int64_t     dt_update;	// Last time of update
    int64_t     dt_sync;	// Last time of sync
};
static volatile struct_shmem_value	*shmem_value;	// SHM value
static volatile uint8_t				*buf;			// buffer for SHM
// ===========================================================================


static volatile bool	EXIT_STATUS, RECONNECT;

#endif //__GBL__
