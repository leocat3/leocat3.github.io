#ifndef WX_PRECOMP
	#include "wx/wx.h"
#endif

#include "wx/string.h"
#include "wx/app.h"
#include "wx/snglinst.h"
#include "wx/socket.h"
#include <wx/dynarray.h>
#include <wx/thread.h>
#include <wx/datetime.h>
#include <wx/textfile.h>
#include <wx/filename.h>
#include <wx/stdpaths.h>

#include <stdio.h>

#ifdef WIN32
	#include <windows.h>
	#include <conio.h>
	#pragma comment(lib, "user32.lib")
//#else
#endif

#include "gbl.h"
#include "print_err.cpp"
#include "ip_thread.cpp"
#include "on_init.cpp"


int main()
{
	int	n, rec_size, shmem_size;
wxString	smn_name;
	//    int         i, j, shmem_size, rec_size, n_rec;
	//    double      f;
	//    uint8_t     *buf;
	//    uint8_t     ui8;
	//    uint16_t    *ui16;
	//    uint64_t    ui64;
	//    HANDLE      hMapFile;

	wxInitializer				initializer;

	IP_THREAD_R	*ip_read;
	IP_THREAD_W	*ip_write;

	EXIT_STATUS = FALSE;


// ---------------------------------------------------------------------------
// wxWindows checkers
// ---------------------------------------------------------------------------
	if ( !initializer )
	{
		print_err( "Failed to initialize the wxWidgets library.");
		return 1;
	}
// ---------------------------------------------------------------------------


//// ---------------------------------------------------------------------------
//// Check for one instance
//// ---------------------------------------------------------------------------
//	if( checker.Create( wxT( ".dss.lock" ) ) )
//	{
//		if ( checker.IsAnotherRunning() )
//		{
//			print_err( "Another instance of the program is running." );
//			fflush( stderr );
//			return -1;
//		}
//	}
//	else // failed to create
//	{
//		print_err( "Failed to init wxSingleInstanceChecker." );
//		return -1;
//	}
//// ---------------------------------------------------------------------------

	n = OnInit();	// Read parametrs
	if( n != 0 )
	{
		return 1;
	}

	sock_client = NULL;


// ---------------------------------------------------------------------------
// Connect to SHM
// ---------------------------------------------------------------------------
    rec_size = sizeof( struct_shmem_value );            // record size

    hMapFile = OpenFileMapping( FILE_MAP_ALL_ACCESS,    // read/write access
                                FALSE,                  // do not inherit the name
                                SHMEM_OBJECT_NAME );    // name of mapping object

    if( hMapFile == NULL )
    {
        print_err( "Could not open file mapping object." );
        return 1;
    }

    shmem_size = rec_size * MAX_VALUE_NN;
    buf = (uint8_t*) MapViewOfFile( hMapFile,               // handle to map object
                                    FILE_MAP_ALL_ACCESS,    // read/write permission
                                    0,
                                    0,
                                    shmem_size );

    if( buf == NULL )
    {
        print_err( "Could not map view of file." );
        CloseHandle( hMapFile );
        return 1;
    }

    shmem_value = ( struct_shmem_value* ) buf;
// ---------------------------------------------------------------------------


// ---------------------------------------------------------------------------
	int	i;

    //printf( "Numbers of records: %d\n\n", shmem_value[0].value );

    printf( "Names:\n------\n" );
    for( i = 1; i < MAX_VALUE_NN; i++ )
    {
        if( shmem_value[i].name[0] != 0 )
        {
                printf( "n=%d name= \"%s\"\n", i, shmem_value[i].name );
        }
    }

    printf( "\n" );
// ---------------------------------------------------------------------------


// ---------------------------------------------------------------------------
// Start socket read
// ---------------------------------------------------------------------------
	ip_read = new IP_THREAD_R();
	if( ip_read->Create() == wxTHREAD_NO_ERROR )
	{
		if( ip_read->Run() != wxTHREAD_NO_ERROR )
		{
			print_err( "IP_THREAD_R Error run." );
			return 1;
		}
	}
	else
	{
		print_err( "IP_THREAD_R Error create." );
		return 1;
	}
// ---------------------------------------------------------------------------


// ---------------------------------------------------------------------------
// Start socket write
// ---------------------------------------------------------------------------
	ip_write = new IP_THREAD_W();
	if( ip_write->Create() == wxTHREAD_NO_ERROR )
	{
		if( ip_write->Run() != wxTHREAD_NO_ERROR )
		{
			print_err( "IP_THREAD_W Error run." );
			return 1;
		}
	}
	else
	{
		print_err( "IP_THREAD_W Error create." );
		return 1;
	}
// ---------------------------------------------------------------------------


printf( "Start DSC\n" );

// ---------------------------------------------------------------------------
// main cycle
// ---------------------------------------------------------------------------
    for( ;; )
    {
		if( EXIT_STATUS )
		{
			return 1;
		}
        Sleep( 15000 );
        //Sleep( 1000 );
		//RECONNECT = true;
//shmem_value[0].access = 'C';
    }

    return 0;
}
