// ===========================================================================
// Service of ETH support
// Communicate between systems
// ===========================================================================

// ===========================================================================
class IP_THREAD_R : public wxThread
// ===========================================================================
{
	private:
		int				MonIndex;
		bool			m_cancelled;
		uint8_t			read_buffer[IP_SIZE];
		//wxSocketBase	*m_socket;

	public:
		IP_THREAD_R()
		{
			m_cancelled	= false;
			//m_socket	= p_socket;


//			//rec_size	= sizeof( struct_shmem_mon );	// record size
//			//shmem_size	= rec_size * 2;		// start shared memory size
//			//n_rec		= shmem_size / rec_size;		// number of record
//
			Create();
		}
//
		virtual			ExitCode Entry();
		virtual void	OnExit();
};
// ===========================================================================


// ===========================================================================
wxThread::ExitCode IP_THREAD_R::Entry()
// ===========================================================================
{
	int			i, j, k, l, m, n, len;
	uint8_t		*ui8, read_buffer[IP_SIZE], name[132], access;
	uint32_t	record_index;
	uint64_t	value, time_in_ticks;
	wxDateTime	dt;

	// ---------------------------------------------------------------------------
	while( !m_cancelled )	// Основной цикл
	// ---------------------------------------------------------------------------
	{


//printf( "sock_client=%d\n", sock_client); fflush( stdout );
		if( sock_client )
		{
			if( sock_client->IsConnected() )
			{

//printf( "if( sock_client->IsConnected() )\n" ); fflush( stdout );
//printf( "read_len=%d\n", sock_client->LastCount() ); fflush( stdout );

				if( sock_client->WaitForRead( TIMEOUT ) )
				{

//printf( "if( sock_client->WaitForRead( -1 ) )\n" ); fflush( stdout );
//printf( "Read 001\n" ); fflush( stdout );

					sock_client->Read( (uint8_t*) read_buffer, 2 );	// read header block of packets

//printf( "read len=%d n_pkt=%d\n", read_buffer[0], read_buffer[1] ); fflush( stdout );

					l = read_buffer[0];	// length of block
					n = read_buffer[1];	// count of blocks

//printf( "read m=%d\n", m ); fflush( stdout );

//sock_client->Read( (uint8_t*) read_buffer, IP_SIZE );	// read buffer

					if( sock_client->WaitForRead( -1 ) )
					{
						for( i = 0; i < n; i++ )
						{
							sock_client->Read( (uint8_t*) read_buffer, l );	// read packet to buffer
							len = sock_client->LastCount();
	
							if( len == l )
							{
								m = sizeof( shmem_value[0].name );

								// Get index in SHM
								ui8 = ( uint8_t* ) &record_index;
								for( j = 0; j < 4; j++ )
								{
									ui8[j] = read_buffer[j];
								}

								// Get name
								for( j = 0; j < m; j++ )
								{
									name[j] = read_buffer[j+4];
								}
	
								access = read_buffer[4+m];
		
								ui8 = ( uint8_t* ) &value;
								for( j = 0; j < 8; j++ )
								{
									ui8[j] = read_buffer[m+j+6];
								}
		
//printf( "read index=%d n=%d p_sn=%d access=%c name=%s value=%u\n",
//record_index,
//i,
//read_buffer[41],
//access,
//name,
//value ); fflush( stdout );

								if( record_index < MAX_VALUE_NN )
								{
									// Set variable name
									k = sizeof( shmem_value[0].name );
									for( j = 0; j < k; j++ )
									{
										shmem_value[record_index].name[j] = name[j];
									}
		
									dt = wxDateTime::UNow();
									//time_in_ticks = dt.GetTicks() * 1000 + dt.GetMillisecond();
									time_in_ticks = dt.GetTicks();
									time_in_ticks = time_in_ticks << 10;
									time_in_ticks = time_in_ticks | dt.GetMillisecond();
									//time_in_ticks = time_in_ticks & 0xFFFFFFFF;
	
////shmem_value[record_index].dt_update = time_in_ticks;	// Last time of update

									shmem_value[record_index].dt_sync = time_in_ticks;	// Last time of sync
									shmem_value[record_index].value = value;			// Set Value
								}	// if( record_index < MAX_VALUE_NN )
							}	// if( len == l )
						}	// for( i = 0; i < n; i++ )
					}	// if( m_socket->WaitForRead( -1 ) )
				}	// if( sock_client->WaitForRead( -1 ) )
			}	// if( sock_client->IsConnected() )
			else
			{
//printf( "wxThread::Sleep( CONNECT_TIMEOUT * 1000 );\n", len ); fflush( stdout );
				wxThread::Sleep( CONNECT_TIMEOUT * 1000 );
			}
		}	// if( sock_client )

//if ( !socket->Read(&read_buffer, 3 ).Error() )
//{
//printf( "Read\n"); 	fflush( stdout );
//}



	}	// while( !m_cancelled )	-- Основной цикл
	// ---------------------------------------------------------------------------
	return 0;
}
// ===========================================================================


// ===========================================================================
void IP_THREAD_R::OnExit()
// ===========================================================================
{
//printf( "Close Read\n"); fflush( stdout );
}
// ===========================================================================


// ===========================================================================
class IP_THREAD_W : public wxThread
// ===========================================================================
{
	private:
		bool			m_cancelled, new_connect;
		uint8_t			write_buffer[IP_SIZE];

	public:
		IP_THREAD_W()
		{
			m_cancelled		= false;
			new_connect		= false;
			RECONNECT		= false;
			addr.Service( ip_port );				// Set port Nn
			addr.Hostname( ip_addr );				// Set IP Address
			sock_client		= new wxSocketClient;	// Create socket

			if( !sock_client )
			{
				m_cancelled = true;
				print_err( "Error create socket." );
			}

			Create();
		}

		virtual			ExitCode Entry();
		virtual void	OnExit();
};
// ===========================================================================


// ===========================================================================
wxThread::ExitCode IP_THREAD_W::Entry()
// ===========================================================================
{
	int			i, j, k, n, len, nn_blk, max_nn_rec, len_name;
	uint8_t		*ui8, ui8a[4], p_sn, len_rec;
	uint32_t	*ui32, record_index;

	/* -----------------------------------------------------------------------
	Packet description
	--------------------------------------------------------------------------
	record_index	4 bytes		index in SHM
	name			36 bytes	name
	p_sn			1 byte		cyclic sequental number of packet
	access			1 byte		Access
	value			8 bytes		Value
	----------------------------------------------------------------------- */

	len_name = sizeof( shmem_value[0].name );
	len_rec	= 4 + len_name + 2 + 8;	// Index of record + Lenth name + p_sn + length access + length value
	max_nn_rec	= 700 / len_rec;	// maximum nn packets in IP packet
	p_sn = 0;

//printf( "len_rec = %d max_nn_rec = %d\n", len_rec, max_nn_rec ); fflush( stdout );

	// ---------------------------------------------------------------------------
	while( !m_cancelled )	// Основной цикл
	// ---------------------------------------------------------------------------
	{
		if( sock_client->IsConnected() ) // Если соединение установлено
		{
//printf( "IsConnected\n" ); fflush( stdout );
			sock_client->WaitForWrite( CONNECT_TIMEOUT );

			if( new_connect	)	// If new connect - send SN
			{
				new_connect	= false;
				for( i = 0; i < IP_SIZE; i++ )
				{
					write_buffer[i] = 0;
				}

				ui32 = ( uint32_t* ) &ui8a;
				*ui32 = sn;
				write_buffer[0] = 1;		// First code
				write_buffer[1] = 1;		// Second code
				write_buffer[2] = ui8a[0];	// SN
				write_buffer[3] = ui8a[1];
				write_buffer[4] = ui8a[2];
				write_buffer[5] = ui8a[3];
				len = 6;
				sock_client->Write( write_buffer, len );
			}	// if( new_connect	)	-- If new connect - send SN
			else
			{
				k = 2;											// 0 byte is length of record; 1 byte is count of record in block
				nn_blk	= 0;
				n = shmem_value[0].value;

				for( i = 0; i < n; i++ )
				{
//printf( "name=%s\n", shmem_value[i].name ); fflush( stdout );
					record_index = i;
					ui8 = ( uint8_t* ) &record_index;
					for( j = 0; j < 4; j++ )					// record index
					{
						write_buffer[k] = ui8[j];
						k++;
					}
					for( j = 0; j < len_name; j++ )				// name
					{
						write_buffer[k] = shmem_value[i].name[j];
						k++;
					}
					write_buffer[k++] = shmem_value[i].access;	// access
					write_buffer[k++] = p_sn;					// cyclic sn of packet
					p_sn++;
					ui8 = ( uint8_t* ) &shmem_value[i].value;	// value to buffer

//printf( "value = %u\n", shmem_value[i].value ); fflush( stdout );

					for( j = 0; j < 8; j++ )
					{
						write_buffer[k++] = ui8[j];
					}

					nn_blk++;
					if( ( nn_blk == max_nn_rec ) || ( i == ( n - 1 ) ) )
					{
//printf( "nn_blk = %d k = %d\n", nn_blk, k ); fflush( stdout );
						write_buffer[0] = len_rec;
						write_buffer[1] = nn_blk;
						nn_blk = 0;
						// write block
						sock_client->WaitForWrite( -1 );
						sock_client->Write( write_buffer, k );
						k = 2;
					}	// if( ( nn_blk == max_nn_rec ) || ( i == ( n - 1 ) ) )
				}	// for( i = 0; i < n - 1; i++ )
			}	// else if( new_connect	)	-- If new connect - send SN

			if( ( sock_client->Error() ) || ( sock_client->LastCount() == 0 ) )
			{
				sock_client->Close();
//printf( "Connect close\n" ); fflush( stdout );
			}

		}	// if( sock_client->IsConnected() ) -- Если соединение установлено
		else
		{
//printf( "Attempt to connect\n" ); fflush( stdout );
			wxThread::Sleep( CONNECT_TIMEOUT * 1000 );
			sock_client->WaitOnConnect( -1 );
			sock_client->Connect( addr );
			new_connect	= true;
		}

		if( RECONNECT )
		{
			if( sock_client->IsConnected() )
			{
//printf( "RECONNECT\n" ); fflush( stdout );
				RECONNECT = false;
				sock_client->Close();
			}
		}
		wxThread::Sleep( DELAY );
	}	// while( !m_cancelled ) -- Основной цикл
	// ---------------------------------------------------------------------------
return 0;
}
// ===========================================================================


// ===========================================================================
void IP_THREAD_W::OnExit()
// ===========================================================================
{
	if( sock_client->IsConnected() ) // Если соединение установлено
	{
		sock_client->Close();
		delete sock_client;
	}
//printf( "Close IP_THREAD_W::Entry()\n"); fflush( stdout );
}
// ===========================================================================
