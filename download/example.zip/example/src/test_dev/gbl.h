#ifndef __GBL__
#define __GBL__

//#define	WIN32
#ifdef WIN32	// if Win then declare nix-like types
    #define     int8_t      __int8
    #define     int16_t     __int16
    #define     int32_t     __int32
    #define     int64_t     __int64
    #define     uint8_t     unsigned __int8
    #define     uint16_t    unsigned __int16
    #define     uint32_t    unsigned __int32
    #define     uint64_t    unsigned __int64
#endif			// WIN32

#ifdef WIN32
	#include <windows.h>
	#define SHMEM_OBJECT_NAME "Global\\test_dev"
#else
	#include <sys/mman.h>
	#include "courbd.h"
	#define SHMEM_OBJECT_NAME "test_dev"
#endif


// ===========================================================================
wxBitmap wxGetBitmapFromMemory( const void *data, size_t length )
// ===========================================================================
{
	wxMemoryInputStream stream( data, length );
	return wxBitmap( stream, wxBITMAP_TYPE_ANY );
}
// ===========================================================================


#ifdef WIN32
	HANDLE hMapFile;
//#else
#endif

#define MAX_VALUE_NN	1024	// Maximun number of values ( SH_MEM )
#define DELAY			100		// Time delay in ms of write cycle 
#define NAME_LENGTH		32		// Length of variable Name

static wxCheckBox		*g_in_0, *g_in_1, *g_in_2, *g_in_3, *g_in_4, *g_in_5, *g_in_6, *g_in_7;
static wxStaticBitmap	*g_out_0, *g_out_1, *g_out_2, *g_out_3, *g_out_4, *g_out_5, *g_out_6, *g_out_7;
static wxTextCtrl		*g_24_inp, *g_24_out;

static volatile	bool	start_frame;
static volatile int		g_cancelled;

	//// W1 array
	//#define W1_NN	30
	//struct  struct_w1
	//{
	//	uint32_t	instance;
	//	char		access;
	//	char		name[32];
	//	int64_t		value;
	//}	w1_array[W1_NN];


// Shared memory support
// ---------------------------------------------------------------------------
struct  struct_shmem_value
// ---------------------------------------------------------------------------
{
    char        name[NAME_LENGTH+4];	// Name of signal/variable
    int64_t     value;					// Value
    char        access;					// Access R/W/F ( Read, Write, Full )
    int64_t     last_update;			// Last time of update
    int64_t     current_datatime;		// Last time of sync
};

static volatile struct_shmem_value *shmem_value;
// ---------------------------------------------------------------------------


static struct_shmem_value shmem_value_base[] =
{
	{ "*",			0,	'*', 0, 0 },	// [0] Number of records
	{ "BIN_INP",	0,	'w', 0, 0 },	// [1] bin out
	{ "BIN_OUT",	0,	'r', 0, 0 },	// [2] bin inp
	{ "24_INP",		0,	'w', 0, 0 },	// [3] 24 inp
	{ "24_OUT",		0,	'r', 0, 0 },	// [4] 24 out
	{ "DT_SYNC",	0,	'r', 0, 0 },	// [5] date time sync

	//{ "01",		0,	'w', 0, 0 },
	//{ "02",		0,	'r', 0, 0 },
	//{ "03",		0,	'w', 0, 0 },
	//{ "04",		0,	'r', 0, 0 },
	//{ "05",		0,	'r', 0, 0 },
	//{ "06",		0,	'w', 0, 0 },
	//{ "07",		0,	'r', 0, 0 },
	//{ "08",		0,	'w', 0, 0 },
	//{ "09",		0,	'r', 0, 0 },
	//{ "10",		0,	'r', 0, 0 },
	//{ "11",		0,	'w', 0, 0 },
	//{ "12",		0,	'r', 0, 0 },
	//{ "13",		0,	'w', 0, 0 },
	//{ "14",		0,	'r', 0, 0 },
	//{ "15",		0,	'r', 0, 0 },
	//{ "16",		0,	'w', 0, 0 },
	//{ "17",		0,	'r', 0, 0 },
	//{ "18",		0,	'w', 0, 0 },
	//{ "19",		0,	'r', 0, 0 },
	//{ "20",		0,	'r', 0, 0 },
	//{ "21",		0,	'w', 0, 0 },
	//{ "22",		0,	'r', 0, 0 },
	//{ "23",		0,	'w', 0, 0 },
	//{ "24",		0,	'r', 0, 0 },
	//{ "25",		0,	'r', 0, 0 },
	//{ "26",		0,	'w', 0, 0 },
	//{ "27",		0,	'r', 0, 0 },
	//{ "28",		0,	'w', 0, 0 },
	//{ "29",		0,	'r', 0, 0 },
	//{ "30",		0,	'r', 0, 0 },
	//{ "31",		0,	'w', 0, 0 },
	//{ "32",		0,	'r', 0, 0 },
	//{ "33",		0,	'w', 0, 0 },
	//{ "34",		0,	'r', 0, 0 },
	//{ "35",		0,	'r', 0, 0 },
	//{ "36",		0,	'w', 0, 0 },
	//{ "37",		0,	'r', 0, 0 },
	//{ "38",		0,	'w', 0, 0 },
	//{ "39",		0,	'r', 0, 0 },
	//{ "40",		0,	'r', 0, 0 },
};

#endif //__GBL__
