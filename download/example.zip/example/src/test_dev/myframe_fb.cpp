///////////////////////////////////////////////////////////////////////////
// C++ code generated with wxFormBuilder (version Sep  8 2010)
// http://www.wxformbuilder.org/
//
// PLEASE DO "NOT" EDIT THIS FILE!
///////////////////////////////////////////////////////////////////////////

#include "myframe_fb.h"

///////////////////////////////////////////////////////////////////////////

MyFrameFB::MyFrameFB( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxFrame( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxDefaultSize, wxDefaultSize );
	this->SetFont( wxFont( 16, 74, 90, 92, false, wxT("Times New Roman") ) );
	
	wxBoxSizer* bSizer1;
	bSizer1 = new wxBoxSizer( wxVERTICAL );
	
	m_panel1 = new wxPanel( this, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxTAB_TRAVERSAL );
	wxBoxSizer* bSizer3;
	bSizer3 = new wxBoxSizer( wxVERTICAL );
	
	msg_001 = new wxStaticText( m_panel1, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0 );
	msg_001->Wrap( -1 );
	bSizer3->Add( msg_001, 0, wxALL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	m_panel2 = new wxPanel( m_panel1, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxSUNKEN_BORDER|wxTAB_TRAVERSAL );
	wxFlexGridSizer* fgSizer4;
	fgSizer4 = new wxFlexGridSizer( 2, 8, 0, 0 );
	fgSizer4->SetFlexibleDirection( wxBOTH );
	fgSizer4->SetNonFlexibleGrowMode( wxFLEX_GROWMODE_SPECIFIED );
	
	m_in_7 = new wxCheckBox( m_panel2, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize( 24,-1 ), 0 );
	fgSizer4->Add( m_in_7, 0, wxALL, 5 );
	
	m_in_6 = new wxCheckBox( m_panel2, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize( 24,-1 ), 0 );
	fgSizer4->Add( m_in_6, 0, wxALL, 5 );
	
	m_in_5 = new wxCheckBox( m_panel2, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize( 24,-1 ), 0 );
	fgSizer4->Add( m_in_5, 0, wxALL, 5 );
	
	m_in_4 = new wxCheckBox( m_panel2, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize( 24,-1 ), 0 );
	fgSizer4->Add( m_in_4, 0, wxALL, 5 );
	
	m_in_3 = new wxCheckBox( m_panel2, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize( 24,-1 ), 0 );
	fgSizer4->Add( m_in_3, 0, wxALL, 5 );
	
	m_in_2 = new wxCheckBox( m_panel2, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize( 24,-1 ), 0 );
	fgSizer4->Add( m_in_2, 0, wxALL, 5 );
	
	m_in_1 = new wxCheckBox( m_panel2, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize( 24,-1 ), 0 );
	fgSizer4->Add( m_in_1, 0, wxALL, 5 );
	
	m_in_0 = new wxCheckBox( m_panel2, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize( 24,-1 ), 0 );
	fgSizer4->Add( m_in_0, 0, wxALL, 5 );
	
	m_staticText1 = new wxStaticText( m_panel2, wxID_ANY, wxT("7"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText1->Wrap( -1 );
	fgSizer4->Add( m_staticText1, 0, wxALL, 5 );
	
	m_staticText2 = new wxStaticText( m_panel2, wxID_ANY, wxT("6"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText2->Wrap( -1 );
	fgSizer4->Add( m_staticText2, 0, wxALL, 5 );
	
	m_staticText3 = new wxStaticText( m_panel2, wxID_ANY, wxT("5"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText3->Wrap( -1 );
	fgSizer4->Add( m_staticText3, 0, wxALL, 5 );
	
	m_staticText4 = new wxStaticText( m_panel2, wxID_ANY, wxT("4"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText4->Wrap( -1 );
	fgSizer4->Add( m_staticText4, 0, wxALL, 5 );
	
	m_staticText5 = new wxStaticText( m_panel2, wxID_ANY, wxT("3"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText5->Wrap( -1 );
	fgSizer4->Add( m_staticText5, 0, wxALL, 5 );
	
	m_staticText6 = new wxStaticText( m_panel2, wxID_ANY, wxT("2"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText6->Wrap( -1 );
	fgSizer4->Add( m_staticText6, 0, wxALL, 5 );
	
	m_staticText7 = new wxStaticText( m_panel2, wxID_ANY, wxT("1"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText7->Wrap( -1 );
	fgSizer4->Add( m_staticText7, 0, wxALL, 5 );
	
	m_staticText8 = new wxStaticText( m_panel2, wxID_ANY, wxT("0"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText8->Wrap( -1 );
	fgSizer4->Add( m_staticText8, 0, wxALL, 5 );
	
	m_panel2->SetSizer( fgSizer4 );
	m_panel2->Layout();
	fgSizer4->Fit( m_panel2 );
	bSizer3->Add( m_panel2, 0, wxALL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	msg_002 = new wxStaticText( m_panel1, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0 );
	msg_002->Wrap( -1 );
	bSizer3->Add( msg_002, 0, wxALL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	m_panel3 = new wxPanel( m_panel1, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxSUNKEN_BORDER|wxTAB_TRAVERSAL );
	wxFlexGridSizer* fgSizer6;
	fgSizer6 = new wxFlexGridSizer( 2, 8, 0, 0 );
	fgSizer6->SetFlexibleDirection( wxBOTH );
	fgSizer6->SetNonFlexibleGrowMode( wxFLEX_GROWMODE_SPECIFIED );
	
	m_out_7 = new wxStaticBitmap( m_panel3, wxID_ANY, wxNullBitmap, wxDefaultPosition, wxDefaultSize, 0 );
	fgSizer6->Add( m_out_7, 0, wxALL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	m_out_6 = new wxStaticBitmap( m_panel3, wxID_ANY, wxNullBitmap, wxDefaultPosition, wxDefaultSize, 0 );
	fgSizer6->Add( m_out_6, 0, wxALL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	m_out_5 = new wxStaticBitmap( m_panel3, wxID_ANY, wxNullBitmap, wxDefaultPosition, wxDefaultSize, 0 );
	fgSizer6->Add( m_out_5, 0, wxALL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	m_out_4 = new wxStaticBitmap( m_panel3, wxID_ANY, wxNullBitmap, wxDefaultPosition, wxDefaultSize, 0 );
	fgSizer6->Add( m_out_4, 0, wxALL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	m_out_3 = new wxStaticBitmap( m_panel3, wxID_ANY, wxNullBitmap, wxDefaultPosition, wxDefaultSize, 0 );
	fgSizer6->Add( m_out_3, 0, wxALL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	m_out_2 = new wxStaticBitmap( m_panel3, wxID_ANY, wxNullBitmap, wxDefaultPosition, wxDefaultSize, 0 );
	fgSizer6->Add( m_out_2, 0, wxALL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	m_out_1 = new wxStaticBitmap( m_panel3, wxID_ANY, wxNullBitmap, wxDefaultPosition, wxDefaultSize, 0 );
	fgSizer6->Add( m_out_1, 0, wxALL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	m_out_0 = new wxStaticBitmap( m_panel3, wxID_ANY, wxNullBitmap, wxDefaultPosition, wxDefaultSize, 0 );
	fgSizer6->Add( m_out_0, 0, wxALL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	m_staticText9 = new wxStaticText( m_panel3, wxID_ANY, wxT("7"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText9->Wrap( -1 );
	fgSizer6->Add( m_staticText9, 0, wxALL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	m_staticText10 = new wxStaticText( m_panel3, wxID_ANY, wxT("6"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText10->Wrap( -1 );
	fgSizer6->Add( m_staticText10, 0, wxALL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	m_staticText11 = new wxStaticText( m_panel3, wxID_ANY, wxT("5"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText11->Wrap( -1 );
	fgSizer6->Add( m_staticText11, 0, wxALL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	m_staticText12 = new wxStaticText( m_panel3, wxID_ANY, wxT("4"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText12->Wrap( -1 );
	fgSizer6->Add( m_staticText12, 0, wxALL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	m_staticText13 = new wxStaticText( m_panel3, wxID_ANY, wxT("3"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText13->Wrap( -1 );
	fgSizer6->Add( m_staticText13, 0, wxALL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	m_staticText14 = new wxStaticText( m_panel3, wxID_ANY, wxT("2"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText14->Wrap( -1 );
	fgSizer6->Add( m_staticText14, 0, wxALL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	m_staticText15 = new wxStaticText( m_panel3, wxID_ANY, wxT("1"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText15->Wrap( -1 );
	fgSizer6->Add( m_staticText15, 0, wxALL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	m_staticText16 = new wxStaticText( m_panel3, wxID_ANY, wxT("0"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText16->Wrap( -1 );
	fgSizer6->Add( m_staticText16, 0, wxALL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	m_panel3->SetSizer( fgSizer6 );
	m_panel3->Layout();
	fgSizer6->Fit( m_panel3 );
	bSizer3->Add( m_panel3, 0, wxALL|wxALIGN_CENTER_HORIZONTAL, 5 );
	
	m_staticline1 = new wxStaticLine( m_panel1, wxID_ANY, wxDefaultPosition, wxSize( -1,5 ), wxLI_HORIZONTAL|wxRAISED_BORDER );
	bSizer3->Add( m_staticline1, 0, wxEXPAND|wxTOP|wxBOTTOM, 5 );
	
	wxBoxSizer* bSizer4;
	bSizer4 = new wxBoxSizer( wxVERTICAL );
	
	wxBoxSizer* bSizer7;
	bSizer7 = new wxBoxSizer( wxHORIZONTAL );
	
	msg_003 = new wxStaticText( m_panel1, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0 );
	msg_003->Wrap( -1 );
	bSizer7->Add( msg_003, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5 );
	
	m_24_inp = new wxTextCtrl( m_panel1, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_READONLY );
	bSizer7->Add( m_24_inp, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5 );
	
	bSizer4->Add( bSizer7, 0, wxALIGN_RIGHT, 5 );
	
	m_slider = new wxSlider( m_panel1, wxID_ANY, 50, 0, 100, wxDefaultPosition, wxSize( -1,-1 ), wxSL_AUTOTICKS|wxSL_HORIZONTAL|wxSL_SELRANGE|wxSUNKEN_BORDER );
	bSizer4->Add( m_slider, 0, wxEXPAND|wxALL, 5 );
	
	bSizer3->Add( bSizer4, 1, wxEXPAND, 5 );
	
	m_staticline11 = new wxStaticLine( m_panel1, wxID_ANY, wxDefaultPosition, wxSize( -1,5 ), wxLI_HORIZONTAL|wxRAISED_BORDER );
	bSizer3->Add( m_staticline11, 0, wxEXPAND|wxTOP|wxBOTTOM, 5 );
	
	wxBoxSizer* bSizer6;
	bSizer6 = new wxBoxSizer( wxVERTICAL );
	
	wxBoxSizer* bSizer8;
	bSizer8 = new wxBoxSizer( wxHORIZONTAL );
	
	msg_004 = new wxStaticText( m_panel1, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0 );
	msg_004->Wrap( -1 );
	bSizer8->Add( msg_004, 0, wxALIGN_CENTER_VERTICAL|wxBOTTOM|wxRIGHT|wxLEFT, 5 );
	
	m_24_out = new wxTextCtrl( m_panel1, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize( -1,-1 ), wxTE_READONLY );
	bSizer8->Add( m_24_out, 0, wxALIGN_CENTER_VERTICAL|wxALL, 5 );
	
	bSizer6->Add( bSizer8, 0, wxALIGN_RIGHT, 5 );
	
	m_staticline12 = new wxStaticLine( m_panel1, wxID_ANY, wxDefaultPosition, wxSize( -1,5 ), wxLI_HORIZONTAL|wxRAISED_BORDER );
	bSizer6->Add( m_staticline12, 0, wxEXPAND|wxTOP|wxBOTTOM, 5 );
	
	bSizer3->Add( bSizer6, 0, wxEXPAND, 5 );
	
	m_panel1->SetSizer( bSizer3 );
	m_panel1->Layout();
	bSizer3->Fit( m_panel1 );
	bSizer1->Add( m_panel1, 1, wxEXPAND, 5 );
	
	this->SetSizer( bSizer1 );
	this->Layout();
	bSizer1->Fit( this );
	
	this->Centre( wxBOTH );
	
	// Connect Events
	this->Connect( wxEVT_CLOSE_WINDOW, wxCloseEventHandler( MyFrameFB::OnClose ) );
	m_slider->Connect( wxEVT_SCROLL_CHANGED, wxScrollEventHandler( MyFrameFB::OnScrollChanged ), NULL, this );
}

MyFrameFB::~MyFrameFB()
{
	// Disconnect Events
	this->Disconnect( wxEVT_CLOSE_WINDOW, wxCloseEventHandler( MyFrameFB::OnClose ) );
	m_slider->Disconnect( wxEVT_SCROLL_CHANGED, wxScrollEventHandler( MyFrameFB::OnScrollChanged ), NULL, this );
	
}
