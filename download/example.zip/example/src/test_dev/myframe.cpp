#include "myframe.h"
#include "dev.xpm"


// ===========================================================================
// ===                            MyFrame                                  ===
// ===========================================================================
MyFrame::MyFrame( wxWindow* parent,
				  wxWindowID id,
				  const wxString& title,
				  const wxPoint& pos,
				  const wxSize& size,
				  long style )
	   : MyFrameFB( parent, id, title, pos, size, style )
{
	wxString	s;

	SetIcon( wxIcon( dev_xpm ) );	// Set Icon

	m_out_0->SetBitmap( wxBitmap( wxGetBitmapFromMemory( l_grey, sizeof( l_grey ) ) ) );
	m_out_1->SetBitmap( wxBitmap( wxGetBitmapFromMemory( l_grey, sizeof( l_grey ) ) ) );
	m_out_2->SetBitmap( wxBitmap( wxGetBitmapFromMemory( l_grey, sizeof( l_grey ) ) ) );
	m_out_3->SetBitmap( wxBitmap( wxGetBitmapFromMemory( l_grey, sizeof( l_grey ) ) ) );
	m_out_4->SetBitmap( wxBitmap( wxGetBitmapFromMemory( l_grey, sizeof( l_grey ) ) ) );
	m_out_5->SetBitmap( wxBitmap( wxGetBitmapFromMemory( l_grey, sizeof( l_grey ) ) ) );
	m_out_6->SetBitmap( wxBitmap( wxGetBitmapFromMemory( l_grey, sizeof( l_grey ) ) ) );
	m_out_7->SetBitmap( wxBitmap( wxGetBitmapFromMemory( l_grey, sizeof( l_grey ) ) ) );

	m_24_inp->SetValue( wxT( "12.00" ) );

	g_in_0 = m_in_0;
	g_in_1 = m_in_1;
	g_in_2 = m_in_2;
	g_in_3 = m_in_3;
	g_in_4 = m_in_4;
	g_in_5 = m_in_5;
	g_in_6 = m_in_6;
	g_in_7 = m_in_7;

	g_out_0 = m_out_0;
	g_out_1 = m_out_1;
	g_out_2 = m_out_2;
	g_out_3 = m_out_3;
	g_out_4 = m_out_4;
	g_out_5 = m_out_5;
	g_out_6 = m_out_6;
	g_out_7 = m_out_7;

	g_24_inp = m_24_inp;
	g_24_out = m_24_out;

	start_frame = true;

	msg_001->SetLabel( MSG_001 );
	msg_002->SetLabel( MSG_002 );
	msg_003->SetLabel( MSG_003 );
	msg_004->SetLabel( MSG_004 );

	Show();

	if( g_cancelled )
	{
		if( g_cancelled == 1 )
		{
			wxMessageBox( wxT( "Could not create file mapping object." ) );
		}
		else
		if( g_cancelled == 2 )
		{
			wxMessageBox( wxT( "Could not map view of file." ) );
		}
		else
		if( g_cancelled == 3 )
		{
			wxMessageBox( wxT( "Shared memory size = 0." ) );
		}
		else
		{
			wxMessageBox( wxT( "Uncnown error." ) );
		}
		Close();
	}
}
// === end of MyFrame::MyFrame ===============================================


// ===========================================================================
MyFrame::~MyFrame()
// ===========================================================================
{
	start_frame = false;
}
// ===========================================================================


// ===========================================================================
void MyFrame::OnScrollChanged( wxScrollEvent& WXUNUSED( event ) )
// ===========================================================================
{
	int			i;
	float		f;
	wxString	s;

	i = m_slider->GetValue();
	f = 24.0 / 100.0 * i;
	s.Printf( "%.2f", f );
	m_24_inp->SetValue( s );
}
// ===========================================================================


// ===========================================================================
void MyFrame::OnClose( wxCloseEvent& event )
// ===========================================================================
{
	start_frame = false;
	event.Skip();
}
// ===========================================================================
