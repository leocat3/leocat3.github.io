// ///////////////////////////////////////////////////////////////////////////
// Name:		ip_thread.cpp
// Purpose:		Threads ETH support
// Created:     10/05/2015
// Author:		Alexandr Suvorov
// Version:		$Id: ip_thread.cpp 2693 2015-05-10 19:48:06Z plcс_dev $
// Modified by:
// Copyright:   (c) 2015 Alexandr Suvorov
// Licence:     wxWindows
// ///////////////////////////////////////////////////////////////////////////

// ===========================================================================
// Service of ETH support
// Communicate between systems
// ===========================================================================

// ===========================================================================
class IP_THREAD_R : public wxThread
// ===========================================================================
{
	private:
		bool			m_cancelled;
		//uint8_t			read_buffer[IP_SIZE];
		//wxSocketBase	*socket;

	public:
		IP_THREAD_R()
		{
			m_cancelled		= false;
//socket = p_socket;


//			//rec_size	= sizeof( struct_shmem_mon );	// record size
//			//shmem_size	= rec_size * 2;		// start shared memory size
//			//n_rec		= shmem_size / rec_size;		// number of record
//
			Create();
		}
//
		virtual			ExitCode Entry();
		virtual void	OnExit();
};
// ===========================================================================


// ===========================================================================
wxThread::ExitCode IP_THREAD_R::Entry()
// ===========================================================================
{


//if ( !socket->Read(&read_buffer, 3 ).Error() )
//{
//printf( "Read\n"); 	fflush( stdout );
//}




return 0;
}
// ===========================================================================


// ===========================================================================
void IP_THREAD_R::OnExit()
// ===========================================================================
{
printf( "Close Read\n"); 	fflush( stdout );
	//eth_comm_run = false;
}
// ===========================================================================


// ===========================================================================
class IP_THREAD_W : public wxThread
// ===========================================================================
{
	private:
		bool			m_cancelled;
		uint32_t		rec_size, n_rec, shmem_size;
		uint8_t			*buf;
		uint16_t		*ui16;
		uint64_t		ui64;
		wxIPV4address	addr;	// IPv4 адрес
		wxString		IP_Address;
		unsigned short	IP_Port;
		uint8_t			write_buffer[IP_SIZE];
		HANDLE			hMapFile;

	public:
		IP_THREAD_W()
		{
			m_cancelled	= false;
			m_socket	= NULL;
			IP_Address	= wxT( "127.0.0.1" );;
			IP_Port		= 31001;
			rec_size	= sizeof( struct_shmem_value );	// record size
			shmem_size	= rec_size * 2;					// start shared memory size

			Create();
		}

		virtual			ExitCode Entry();
		virtual void	OnExit();
};
// ===========================================================================


// ===========================================================================
wxThread::ExitCode IP_THREAD_W::Entry()
// ===========================================================================
{
	unsigned int	i, m, n;
	long			l;
	wxString		s, s1, s2, s3;
	//wxString		file_name = wxT( "/root/ctrl.cfg" );
	wxString		file_name = wxT( "ctrl.cfg" );
	wxArrayString	as;
	wxTextFile		inf( file_name );

	while( !start_frame )
	{
		wxMilliSleep( 10 );
	}

	hMapFile = CreateFileMapping( INVALID_HANDLE_VALUE,	// use paging file
								  NULL,					// default security
								  PAGE_READWRITE,		// read/write access
								  0,					// maximum object size (high-order DWORD)
								  shmem_size,			// maximum object size (low-order DWORD)
								  SHMEM_OBJECT_NAME );	// name of mapping object

	if( hMapFile == NULL)
	{
		m_cancelled = true;
		print_err( "Could not create file mapping object(1)." );
	}

	if( !m_cancelled )
	{
		buf = ( uint8_t* ) MapViewOfFile( hMapFile,				// handle to map object
										  FILE_MAP_ALL_ACCESS,	// read/write permission
										  0,
										  0,
										  ( SIZE_T ) shmem_size );
		if( buf == NULL )
		{
			m_cancelled = true;
			CloseHandle( hMapFile );
			print_err( "Could not map view of file(1)." );
		}
	}

	if( !m_cancelled )
	{
		w_shmem_value = ( struct_shmem_value* ) buf;
		ui16 = ( uint16_t* ) &ui64;
		ui64 = w_shmem_value[0].value;
		n_rec = ui16[0];
	}

//s.Printf( "n_rec=%d", n_rec );
//wxMessageBox( s );

	if( !m_cancelled )
	{
		shmem_size = ( rec_size * n_rec ) + rec_size;	// shared memory size
	    UnmapViewOfFile( buf );
		CloseHandle( hMapFile );

		hMapFile = CreateFileMapping( INVALID_HANDLE_VALUE,	// use paging file
									  NULL,					// default security
									  PAGE_READWRITE,			// read/write access
									  0,						// maximum object size (high-order DWORD)
									  shmem_size,				// maximum object size (low-order DWORD)
									  SHMEM_OBJECT_NAME );				// name of mapping object

		if( hMapFile == NULL)
		{
			m_cancelled = true;
			print_err( "Could not create file mapping object(2)." );
		}
	}

	if( !m_cancelled )
	{
		buf = ( uint8_t* ) MapViewOfFile( hMapFile,				// handle to map object
										  FILE_MAP_ALL_ACCESS,	// read/write permission
										  0,
										  0,
										  ( SIZE_T ) shmem_size );
		if( buf == NULL )
		{
			m_cancelled = true;
			CloseHandle( hMapFile );
			print_err( "Could not map view of file(2)." );
		}
	}

	if( !m_cancelled )
	{
		w_shmem_value = ( struct_shmem_value* ) buf;
		//ui16 = ( uint16_t* ) &ui64;
	}

	// Read IP Port & IP Address
	if( inf.Exists() )
	{
		if( inf.Open( file_name, wxConvLocal ) )
		{
			n = 0;
			//for ( s = inf.GetFirstLine(); ( !inf.Eof() && ( s[0] != 0 ) ); s = inf.GetNextLine() )
			for ( s = inf.GetFirstLine(); !inf.Eof(); s = inf.GetNextLine() )
			{
				n++;
				if( as.Count() < ( unsigned int ) n )
					as.Add( s );
				else
					as[n-1] = s;
			}
			inf.Close();

			n = as.Count();
			for( i = 0; i < n; i++ )
			{
				s = as[i];
				s = s.Trim( false );
				s = s.Trim( true );
				s = s.Upper();
				s.Replace( "\t", " " );
				s.Replace( "  ", " " );
				if( s != wxEmptyString )
				{
					s1 = s2 = s3 = wxEmptyString;
					m = s.Find( ' ', true );
					if( m != wxNOT_FOUND )
					{
						s3 = s.Mid( m + 1 );
						s.Truncate( m );
						m = s.Find( ' ', true );
						if( m != wxNOT_FOUND )
						{
							s2 = s.Mid( m + 1 );
							s.Truncate( m );
							s1 = s;
						}
					}

					if( s1 == wxT( "NET" ) )
					{
						if( s2 == wxT( "IP" ) )
						{
							IP_Address = s3;
						}
						else
						if( s2 == wxT( "PORT" ) )
						{
							s3.ToLong( &l );
							IP_Port = l;
						}
					}	// if( s1 == wxT( "NET" ) )
				}	// if( s != wxEmptyString )
			}	// for( i = 0; i < n; i++ )
		}	// if( inf.Open( file_name, wxConvLocal ) )
	}	// if( inf.Exists() )

//s.Printf( "IP=%d Addr=%s", IP_Port, IP_Address.c_str() );
//wxMessageBox( s );

	addr.Service( IP_Port );		// Set port Nn
	addr.Hostname( IP_Address );	// Set IP Address
	m_socket = new wxSocketClient;	// Create socket

	if( !m_socket )
	{
		m_cancelled = true;
		print_err( "Error create socket." );
	}

	while( !m_cancelled )
	{


	}	// while( !m_cancelled )


//s.Printf( "n_rec=%d", n_rec );
//wxMessageBox( "Exist" );





//socket->Close();
//if ( !socket->Read(&read_buffer, 3 ).Error() )
//{
//printf( "Read\n"); 	fflush( stdout );
//}

return 0;
}
// ===========================================================================


// ===========================================================================
void IP_THREAD_W::OnExit()
// ===========================================================================
{
//wxMessageBox( "Close Write\n");
	UnmapViewOfFile( buf );
	CloseHandle( hMapFile );
}
// ===========================================================================


	//// ===========================================================================
	//class IP_THREAD_MON : public wxThread
	//// ===========================================================================
	//{
	//	private:
	//		bool	m_cancelled, max_socket_count;
	//		int		shmem_size, rec_size, shm, n_rec;
	//	    uint8_t	*buf;
	//
	//        //bool	close;
	//
	//		//uint8_t	read_buffer[IP_SIZE];
	//		//uint8_t	write_buffer[IP_SIZE];
	//
	//		wxIPV4address	addr, addr_info;
	//		wxSocketServer	*server;
	//		wxSocketBase	*socket;
	//
	//		IP_THREAD_R		*ip_read;
	//		IP_THREAD_W		*ip_write;
	//
	//		//wxSocketClient	*m_socket;					// Адрес соккета клиента
	//
	//	public:
	//		IP_THREAD_MON()
	//		{
	//			m_cancelled			= false;
	//			max_socket_count	= false;
	//			socket				= NULL;
	//
	//			rec_size			= sizeof( struct_shmem_mon );	// record size
	//			shmem_size			= rec_size * MAX_CONNECT_NN;	// shared memory size
	//
	//			Create();
	//		}
	//
	//		virtual			ExitCode Entry();
	//		virtual void	OnExit();
	//
	//};
	//// ===========================================================================
	//
	//
	//// ===========================================================================
	//wxThread::ExitCode IP_THREAD_MON::Entry()
	//// ===========================================================================
	//{
	//	int	i, j, len;
	//
	////wxString s;
	//
	//	addr.Service( PORT_SRV );	// Set port for listen
	//	//addr.Hostname( IP_ADDR );
	//
	////s.Printf( "% 14u", 0xffffffff );
	////printf( "% 20u\n", 0xffffffff );
	//
	//
	//	hMapFile_MON = CreateFileMapping( INVALID_HANDLE_VALUE,	// use paging file
	//									  NULL,					// default security
	//									  PAGE_READWRITE,		// read/write access
	//									  0,					// maximum object size (high-order DWORD)
	//									  shmem_size,			// maximum object size (low-order DWORD)
	//									  SHMEM_OBJECT_NAME );	// name of mapping object
	//
	//	if( hMapFile_MON == NULL )
	//	{
	//		print_err( "Failed to create MON SHM." );
	//		m_cancelled = true;
	//	}
	//
	//	if( !m_cancelled )
	//	{
	//		buf = ( uint8_t* ) MapViewOfFile( hMapFile_MON,			// handle to map object
	//										  FILE_MAP_ALL_ACCESS,	// read/write permission
	//										  0,
	//										  0,
	//										  ( SIZE_T ) shmem_size );
	//		if( buf == NULL )
	//		{
	//			print_err( "Failed to create buffer MON SHM." );
	//			m_cancelled = true;
	//			CloseHandle( hMapFile_MON );
	//		}
	//	}
	//
	////printf( "buf1 = %d\n.", buf ); fflush( stdout );
	//
	//	// отобразить буфер на массив записей, записи очистить
	//	if( !m_cancelled )
	//	{
	//		shmem_mon = ( struct_shmem_mon* ) buf;
	//		len = sizeof( shmem_mon[0].ip );
	//
	//		// Clear chared memory
	//		for( i = 0; i < MAX_CONNECT_NN; i++ )
	//		{
	//			shmem_mon[i].socket = 0;
	//			shmem_mon[i].instance = 0;
	//			for( j = 0; j < len; j++ )
	//			{
	//				shmem_mon[i].ip[j] = 0;
	//			}
	//			shmem_mon[i].status = '-';
	//		}
	//
	//		// Create socket server
	//		server = new wxSocketServer( addr );
	//		if ( !server->Ok() )
	//		{
	//			print_err( "Failed to create port server." );
	//			m_cancelled = true;
	//		}
	//	}
	//
	////else
	////{
	////socket = new wxSocketBase;
	////socket->SetTimeout( 1 );
	////printf( "Create SocketBase\n" ); fflush( stdout );
	////}
	//
	//// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	//// Основной цикл
	//// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	//	while( !m_cancelled )
	//	{
	//		socket = new wxSocketBase;
	//
	//printf( "Create SocketBase\n" ); fflush( stdout );
	//
	//if( socket )
	//{
	////socket->Wait( 10 );
	////socket->SetTimeout( 10 );
	//socket = server->Accept();
	//printf( "wxSocketServer Accept()\n"); fflush( stdout );
	//socket->GetPeer( addr_info );
	//printf( "%s %s : %d\n", addr_info.IPAddress().c_str(), addr_info.Hostname().c_str(), addr_info.Service() ); fflush( stdout );
	//
	//j = -1;
	//for( i = 0; i < MAX_CONNECT_NN; i++ )
	//{
	//if( shmem_mon[i].socket == 0 )
	//{
	//j = i;
	//break;
	//}
	//}
	//
	//if( j < 0 )
	//{
	//if( !max_socket_count )
	//{
	//print_err( "Reached the maximum number of socket." );
	//}
	//max_socket_count = true;
	//}
	//else
	//{
	//shmem_mon[j].socket = ( uint32_t ) socket;
	//strcpy( ( char* ) shmem_mon[j].ip, addr_info.IPAddress().c_str() );
	//}
	//
	//ip_read = new IP_THREAD_R( socket );
	//if( ip_read->Create() == wxTHREAD_NO_ERROR )
	//{
	//	if( ip_read->Run() != wxTHREAD_NO_ERROR )
	//	{
	//		print_err( "IP_THREAD_R Error run." );
	//		m_cancelled = true;
	//		//return 0;
	//	}
	//}
	//else
	//{
	//	print_err( "IP_THREAD_R Error create." );
	//	m_cancelled = true;
	//	//return 0;
	//}
	//
	//ip_write = new IP_THREAD_W( socket );
	//if( ip_write->Create() == wxTHREAD_NO_ERROR )
	//{
	//	if( ip_write->Run() != wxTHREAD_NO_ERROR )
	//	{
	//		print_err( "IP_THREAD_W Error run." );
	//		m_cancelled = true;
	//		//return 0;
	//	}
	//}
	//else
	//{
	//	print_err( "IP_THREAD_W Error create." );
	//	m_cancelled = true;
	//	//return 0;
	//}
	//
	//
	//
	//
	//
	//
	//
	//
	//
	////if ( !socket->Read(&read_buffer, 3 ).Error() )
	////{
	////printf( "Read\n"); 	fflush( stdout );
	////}
	//
	//
	////socket = NULL;
	//
	//
	////server->SetTimeout(10); // 10
	//
	//
	//		//while( socket->IsConnected() )
	//		//{
	//		//
	//		//printf( "wxSocketServer Connect()\n"); fflush( stdout );
	//		//		// for( ;; )
	//		//		// {
	//		//		// if ( socket->Read(&read_buffer, 11 ).Error() )
	//		//		// {
	//		//		// break;
	//		//		// }
	//		//		//
	//		//		// 	len = socket->LastCount();
	//		//		// 	//printf( "len=%d", len );
	//		//		//
	//		//		// if( len == 11 )
	//		//		// {
	//		//		//
	//		//		// 	//	len = socket->LastCount();
	//		//		// 	//	printf( "len=%d %d %d %d %d %d %d %d %d %d %d %d\n", len, \
	//		//		// 	//	read_buffer[0], \
	//		//		// 	//	read_buffer[1], \
	//		//		// 	//	read_buffer[2], \
	//		//		// 	//	read_buffer[3], \
	//		//		// 	//	read_buffer[4], \
	//		//		// 	//	read_buffer[5], \
	//		//		// 	//	read_buffer[6], \
	//		//		// 	//	read_buffer[7], \
	//		//		// 	//	read_buffer[8], \
	//		//		// 	//	read_buffer[9], \
	//		//		// 	//	read_buffer[10] );
	//		//		// 	//	fflush( stdout );
	//		//		//
	//		//		// }
	//		//		//
	//		//		//
	//		//		// }	// for( ;; )
	//		//
	//		//}	// while( socket->IsConnected() )
	//
	////printf( "wxSocketServer Lost connect\n"); 	fflush( stdout );
	//
	//
	//}	// if( socket )
	//
	//
	//		if( TestDestroy() )
	//			m_cancelled = true;
	//
	//		//wxThread::Sleep( 1 );
	////		wxThread::Sleep( 1000 );
	//
	//	}	// while( !m_cancelled )
	//
	//	print_err( "Close MON thread" );
	//	return 0;
	//}
	//// ===========================================================================
	//
	//
	//// ===========================================================================
	//void IP_THREAD_MON::OnExit()
	//// ===========================================================================
	//{
	//	delete server;
	//	UnmapViewOfFile( buf );
	//	CloseHandle( hMapFile_MON );
	//}
	//// ===========================================================================
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//		//	// ===========================================================================
	//		//	class ETH_THREAD_W : public wxThread
	//		//	// ===========================================================================
	//		//	{
	//		//		private:
	//		//			bool	m_cancelled;
	//		//	        bool	close;
	//		//
	//		//			uint8_t	read_buffer[ETH_SIZE];	// буфер данных на чтение
	//		//			uint8_t	write_buffer[ETH_SIZE];	// буфер данных на запись
	//		//
	//		//	wxIPV4address	addr;	// IP адрес
	//		//	wxSocketServer	*server;
	//		//	//wxSocketBase	*socket;
	//		//	wxSocketClient	*socket;					// Адрес соккета клиента
	//		//
	//		//	//wxSocketServer *server = new wxSocketServer(addr);
	//		//	//wxSocketBase *socket = server->Accept();
	//		//
	//		//
	//		//
	//		//			//wxSocketClient	*m_socket;					// Адрес соккета клиента
	//		//
	//		//		public:
	//		//			ETH_THREAD_W()
	//		//			{
	//		//				m_cancelled		= false;
	//		//
	//		//				Create();
	//		//			}
	//		//
	//		//			virtual			ExitCode Entry();
	//		//			virtual void	OnExit();
	//		//
	//		//	};
	//		//	// ===========================================================================
	//		//
	//		//
	//		//	// ===========================================================================
	//		//	wxThread::ExitCode ETH_COMM_W::Entry()
	//		//	// ===========================================================================
	//		//	{
	//		//		int	len;
	//		//
	//		//	uint8_t	ui1, ui2;
	//		//	uint16_t	ui16;
	//		//
	//		//		addr.Service( IP_COMM_PORT );
	//		//		addr.Hostname( IP_COMM_ADDR );
	//		//
	//		//
	//		//	//printf( "---001---\n" ); fflush( stderr );
	//		//
	//		//
	//		//
	//		//		socket = new wxSocketClient;						// Создаем сокет
	//		//		if( !socket )
	//		//		{
	//		//			m_cancelled = true;		// не смогли создать соккет, закрыть поток
	//		//			fprintf( stderr, "%s Srv_PF755: Error create ETH_COMM socket\n", \
	//		//				wxDateTime::Now().Format( "[%Y/%m/%d %H:%M:%S]" ).c_str() );
	//		//			fflush( stderr );
	//		//		}
	//		//
	//		//	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	//		//	// Основной цикл
	//		//	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	//		//		while( !m_cancelled )
	//		//		{
	//		//
	//		//	//printf( "---002---\n" ); fflush( stderr );
	//		//
	//		//
	//		//			if( socket->IsConnected() )						// Если соединение установлено
	//		//			{
	//		//
	//		//	//printf( "---003---\n" ); fflush( stderr );
	//		//
	//		//	socket->SetTimeout(2);
	//		//					//socket->SetNotify( wxSOCKET_LOST_FLAG ); // Отслеживать потерю соединения	//	}	// for( ;; )
	//		//
	//		//					socket->WaitForWrite( 5 );
	//		//					//m_socket->Write( write_buffer, len );
	//		//					socket->Write( write_buffer, 22 );
	//		//
	//		//	if( socket->Error() )
	//		//	{
	//		//	printf( "---Error/Close---\n" ); fflush( stderr );
	//		//	socket->Close();
	//		//
	//		//
	//		//	}
	//		//
	//		//			}
	//		//			else
	//		//			{
	//		//
	//		//
	//		//	//printf( "---004---\n" ); fflush( stderr );
	//		//
	//		//
	//		//	//			if(	!CONNECT_ERR )
	//		//	//			{
	//		//	//				//CONNECT_ERR = true;	//	socket = server->Accept();
	//		//	//				fprintf( stderr, "%s Srv_PF755: Failed to connect for FP755\n", \	//	if( socket )
	//		//	//					wxDateTime::Now().Format( "[%Y/%m/%d %H:%M:%S]" ).c_str() );	//	{
	//		//	//				fflush( stderr );	//	printf( "wxSocketServer Accept()\n"); 	fflush( stdout );
	//		//	//			}	//
	//		//		//	server->SetTimeout(10); // 1 min
	//		//				if( socket )	//	while( socket->IsConnected() )
	//		//				{	//	{
	//		//
	//		//	//printf( "---005---\n" ); fflush( stderr );
	//		//
	//		//
	//		//	//				SESSION_CREATE	= false;			// сессия с частотником потеряна	//	printf( "wxSocketServer Connect()\n"); fflush( stdout );
	//		//	//				ENABLE_CONTROL	= false;			// управление не определено	//	for( ;; )
	//		//		//	{
	//		//					socket->Connect( addr, false );	// Пытаемся соедениться с сервером	//	if ( socket->Read(&read_buffer, ETH_SIZE ).Error() )
	//		//					socket->WaitOnConnect( 10 );		// Ожидание соединения 10 сек.	//	{
	//		//		//	break;
	//		//					if( socket->IsConnected() )		// Если соединение установлено	//	}
	//		//					{	//	len = socket->LastCount();
	//		//
	//		//	//printf( "---006---\n" ); fflush( stderr );
	//		//
	//		//
	//		//
	//		//	//					if(	CONNECT_ERR )	//	printf( "len=%d\n", len ); fflush( stdout );
	//		//	//					{	//
	//		//	//						CONNECT_ERR = false;	//
	//		//	//						fprintf( stderr, "%s Srv_PF755: Now is connect to FP755\n", \	//
	//		//	//							wxDateTime::Now().Format( "[%Y/%m/%d %H:%M:%S]" ).c_str() );	//
	//		//	//						fflush( stderr );	//
	//		//	//					}	//
	//		//		//
	//		//						socket->SetNotify( wxSOCKET_CONNECTION_FLAG | wxSOCKET_INPUT_FLAG | wxSOCKET_LOST_FLAG ); // Отслеживать потерю соединения	//	}	// for( ;; )
	//		//					}	//	}	// while( socket->IsConnected() )
	//		//				}	//	}	// if( socket )
	//		//			}
	//		//
	//		//
	//		//
	//		//
	//		//
	//		//
	//		//
	//		//
	//		//
	//		//
	//		//			if( TestDestroy() )
	//		//				m_cancelled = true;
	//		//
	//		//			wxThread::Sleep( 20 );
	//		//			//wxThread::Sleep( 1200 );
	//		//
	//		//		}	// while( !m_cancelled )
	//		//
	//		//		return 0;
	//		//	}
	//		//	// ===========================================================================
	//		//
	//		//
	//		//	// ===========================================================================
	//		//	void ETH_COMM_W::OnExit()
	//		//	// ===========================================================================
	//		//	{
	//		//		eth_comm_w_run = false;
	//		//	}
	//		//	// ===========================================================================
